# Artificial Life Desktop Pet — Integrated Organism Build (v0.4.0)

This is a **native desktop pet**, not a web page. It opens a small draggable always-on-top creature and a native Brain Console. It does not start a localhost web server; no browser or IP address is required.

> The word *organism* describes the architecture and project goal. This software does not claim subjective consciousness, sentience, feelings, or biological life.

## Start here

### Windows

1. Install Python 3.10 or newer. During installation, enable the Python launcher (`py`) and ensure Tk/Tcl is included.
2. Extract the ZIP to a folder you control.
3. Open PowerShell in that folder and install the small helper dependencies:

   ```powershell
   py -m pip install -r requirements.txt
   ```

4. Double-click `run_windows.bat` or run:

   ```powershell
   py run.py
   ```

### Linux / macOS

Install Python 3.10+ and Tkinter (`python3-tk` on many Debian/Ubuntu systems), then:

```bash
python3 -m pip install -r requirements.txt
python3 run.py
```

The pet appears as a floating pixel-inspired teal creature. Double-click it to open the console; right-click for pause/resume and exit. On first launch the console opens automatically. The database is stored under `data/` by default. Set `ALIFE_HOME` before launch to choose a different home folder.

## What the desktop console now includes

The top-level `Agency` tab contains nested panels for Goals, Predictions, Files, Colony, and Neural core. The Colony panel includes controls to start, pause/resume, and stop an individual child runtime or start/stop all child runtimes.

- **Persistent knowledge graph:** statements, concept nodes, provenance labels, associations, feedback, activation, and activity journal are stored in SQLite.
- **Spreading activation:** query concepts activate related memories over up to three graph hops. Potential-conflict edges are excluded from supporting activation.
- **Adaptive recurrent substrate:** a 24-unit recurrent state machine processes each ingested text or question through several micro-steps. On learned input, local Oja-style plasticity updates bounded recurrent and input weights. Its input features are deterministic hashed lexical features. It is an experiment scaffold, not a pretrained neural language model, semantic understanding, or a consciousness mechanism.
- **Optional local semantic retrieval:** if an embedding model is configured, `organism/semantic.py` calls Ollama only at `127.0.0.1:11434`, caches vectors in SQLite, and can rerank cached memories. The UI indexes up to 100 unindexed memories per click; press again for the next batch. If the model is missing or fails, lexical/graph retrieval still works. Semantic retrieval is disabled by default.
- **Optional local language model:** the Ask tab can use Ollama for evidence-grounded response phrasing. Set `ALIFE_OLLAMA_MODEL` before launch to name a local model. Model output is not executed as code.
- **Managed goals:** create objectives and success criteria, set priorities, record progress notes, and change status. Goals are advisory; they do not autonomously execute external actions.
- **Prediction/outcome records:** record expected outcomes and self-reported confidence, then compare them with observations. The current error score is word-overlap similarity, not calibrated probability or a trained world model.
- **Explicit file grants:** browse to one text/code file, grant access, ingest it separately, and revoke access. Supported types are `.txt`, `.md`, `.rst`, `.py`, `.json`, `.csv`, and `.log`, with a 1 MB default size cap. No recursive crawling, screen recording, clipboard capture, microphone capture, or background file watching is included.
- **Colony creator console:** create isolated local organism databases with separate IDs, parent/child generation metadata, and optional inheritance of up to 500 knowledge statements. Send a message to a selected organism or broadcast to colony members. Inbox envelopes are encrypted and authenticated using Fernet; the key is stored in the colony folder, so protect that folder. This local prototype is not a network protocol and is not safe against an attacker who can read the same user's data/key.
- **Runtime protections:** ingestion and query budgets remain active. When `psutil` is installed, CPU/RSS monitoring backs off background cognition for a cooldown after soft thresholds are exceeded. These are application-level soft limits, not OS-enforced resource quotas or a sandbox.
- **Crash diagnostics and backups:** rotating `runtime.log`, `fatal_tracebacks.log`, consistent SQLite backups roughly every ten minutes and at orderly shutdown, quick-check of backup integrity, and retention of the three newest snapshots.

## Optional local Ollama models

The core does not require Ollama. To enable answer generation, install Ollama and pull a chat model, for example:

```bash
ollama pull qwen2.5:3b
```

Set `ALIFE_OLLAMA_MODEL=qwen2.5:3b` before launching. To enable semantic embeddings as well:

```bash
ollama pull nomic-embed-text
```

Set `ALIFE_OLLAMA_EMBED_MODEL=nomic-embed-text` before launching. In PowerShell for the current session:

```powershell
$env:ALIFE_OLLAMA_MODEL = "qwen2.5:3b"
$env:ALIFE_OLLAMA_EMBED_MODEL = "nomic-embed-text"
py run.py
```

Embedding generation may take time on the first index. Start with small batches and use the console's Neural core tab to inspect index counts. All model requests in this build use the loopback endpoint; no hosted embedding service is called.

## Resource tuning

Optional environment variables:

- `ALIFE_MAX_RSS_MB` (default 1024): soft resident-memory threshold at which background cognition backs off.
- `ALIFE_MAX_CPU_PERCENT` (default 85): soft process CPU threshold; psutil reports process CPU and may exceed 100% on multi-core systems.
- `ALIFE_HOME`: data / logs / backups location.

These thresholds are monitoring and scheduling heuristics. They do **not** hard-kill the process or enforce a CPU/RAM ceiling at the operating-system level.

## Tests

From the project directory:

```bash
python -m py_compile run.py desktop_pet.py organism/*.py tests/*.py
python -m unittest discover -s tests -v
```

A native Tk UI + child-runtime smoke test can be run on Windows with `powershell -ExecutionPolicy Bypass -File .\scripts\validate_windows.ps1`. On Linux, a graphical smoke test can be run with Xvfb installed:

```bash
ALIFE_HOME=/tmp/alife-v3-smoke xvfb-run -a python - <<'PY'
from organism.store import OrganismStore
from organism.brain import Brain
from desktop_pet import DesktopPet
s = OrganismStore('/tmp/alife-v3-smoke')
a = DesktopPet(s, Brain(s))
a.root.after(1800, a.close)
a.run()
print('desktop UI smoke passed')
PY
```

The current suite contains **28 automated tests** covering persistent identity and graph operations, retrieval, the recurrent plasticity update, optional semantic cache/ranking with a stubbed backend, goals, prediction/outcome records, explicit file grants, encrypted colony messages and tamper detection, backups, pause/budgets, and the retained authenticated legacy API. On Linux, `scripts/windows_desktop_smoke.py` was exercised with Xvfb. For an actual native Windows run, use `powershell -ExecutionPolicy Bypass -File .\scripts\validate_windows.ps1`; GitHub Actions configuration is included at `.github/workflows/windows-desktop-validation.yml`. A successful Linux/Xvfb run does not mean the native-Windows run has passed.

## Important boundaries

- The recurrent substrate is small and randomly initialized; online plasticity demonstrates parameter adaptation, not language learning or a brain comparable to a biological nervous system.
- Local Ollama embeddings are an optional external model running on the same machine. They are not bundled and semantic retrieval is not enabled without configuration and indexed vectors.
- Child colony profiles now run their own concurrent cognition loop in separate supervised Python processes, but child organisms do not yet get individual visible desktop overlays. The primary organism remains the sole floating pet.
- Colony messages use one local shared encryption key, do not traverse a network, and do not provide per-organism public-key identities, key rotation, or protection against compromise of the local user account.
- The runtime monitor uses soft thresholds. It does not provide true OS-level quotas, arbitrary-code sandboxing, or crash-free guarantees.
- It does not automatically browse the web or inspect the whole computer and does not execute shell commands, self-modify source code, or perform unrestricted OS actions.
- Nothing in the code or tests proves subjective experience or consciousness. See `CAPABILITY_GAPS.md` for the research boundaries and remaining engineering roadmap.

## Project layout

- `desktop_pet.py`: floating desktop body, Brain Console, integrated Agency UI and safe interaction handlers.
- `organism/brain.py`: knowledge intake, graph growth, reflection, retrieval and evidence reporting.
- `organism/dynamics.py`: persistent recurrent state and bounded local online plasticity.
- `organism/semantic.py`: optional local Ollama embedding cache and similarity ranking.
- `organism/goals.py`, `prediction.py`, `permissions.py`, `colony.py`: integrated goal, prediction, explicitly granted file and colony services.
- `organism/runtime_guard.py`: soft resource observation, background backoff and SQLite snapshots.
- `organism/runtime_supervisor.py`, `organism/worker.py`: separate-process colony lifecycle, heartbeat, restart/backoff and worker loop.
- `scripts/validate_windows.ps1`, `scripts/windows_desktop_smoke.py`, `VALIDATION.md`: native Windows validation command and truthful test-status record.
- `organism/store.py`: SQLite persistence and migration.
- `organism/server.py` and `web/`: retained legacy local API/dashboard code, not launched by `run.py`.
- `tests/`: unit and API tests.
