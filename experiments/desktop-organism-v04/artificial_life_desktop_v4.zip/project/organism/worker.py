"""Child-organism process entry point used by ColonyRuntimeSupervisor.

A worker performs bounded local cognition, updates health, and counts pending inbox
messages. Messages are untrusted input and are never interpreted as commands or code.
"""
from __future__ import annotations

import argparse
import json
import os
import signal
import time
import traceback
from pathlib import Path

from .brain import Brain
from .life import LifeController
from .store import OrganismStore


def _read(path: Path, default):
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError, ValueError):
        return default


def _atomic_write(path: Path, payload: dict) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_suffix(path.suffix + ".tmp")
    temporary.write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")
    os.replace(temporary, path)


def _parent_alive(pid: int) -> bool:
    if pid <= 0:
        return False
    try:
        os.kill(pid, 0)
        return True
    except PermissionError:
        return True
    except OSError:
        return False


def run_worker(home: str, organism_id: str, colony_home: str, control: str,
               heartbeat: str, supervisor_pid: int, tick_seconds: float = 5.0,
               orphan_timeout: float = 20.0) -> int:
    home_path, control_path, heartbeat_path = Path(home).resolve(), Path(control), Path(heartbeat)
    status_path = home_path / "runtime_status.json"
    store = None
    state = "starting"
    try:
        store = OrganismStore(str(home_path))
        identity = store.get_meta("identity", {})
        if identity.get("id") != organism_id:
            raise RuntimeError("organism identity does not match its registry entry")
        brain = Brain(store, semantic_autoindex=False)
        try:
            reflection_seconds = float(os.environ.get("ALIFE_CHILD_REFLECTION_SECONDS", "60"))
        except ValueError:
            reflection_seconds = 60.0
        life = LifeController(store, brain, reflection_interval_seconds=max(15.0, reflection_seconds))
        store.log("child_runtime_started", {"pid": os.getpid(), "isolation": "separate-process"})
        store.db.commit()
        state = "running"
        last_status = 0.0
        last_cycle = None
        last_error = None
        while True:
            now = time.time()
            command = _read(control_path, {"state": "running"}).get("state", "running")
            if command in ("stopped", "shutdown"):
                state = "stopped"
                break
            hb = _read(heartbeat_path, {})
            fresh = now - float(hb.get("timestamp", 0.0) or 0.0) <= orphan_timeout
            if hb.get("alive") is False or not fresh or not _parent_alive(supervisor_pid):
                state = "orphaned"
                break
            paused = command == "paused"
            if bool(store.get_meta("paused", False)) != paused:
                store.set_meta("paused", paused)
                with store.db:
                    store.log("runtime_paused" if paused else "runtime_resumed", {"pid": os.getpid()})
            if not paused:
                last_cycle = life.tick()
            inbox = store.get_meta("inbox", []) or []
            pending = sum(1 for item in inbox if not item.get("read", False))
            if now - last_status >= 1.0:
                status = {
                    "organism_id": organism_id, "name": identity.get("name", "Organism"), "pid": os.getpid(),
                    "state": "paused" if paused else "running", "desired_state": command,
                    "last_heartbeat": now, "started_at": float(store.get_meta("runtime_started_at", now) or now),
                    "cycle_count": life.state().get("cycle_count", 0),
                    "reflection_count": life.state().get("reflection_count", 0),
                    "knowledge_items": store.status().get("knowledge_items", 0),
                    "neurons": store.status().get("neurons", {}).get("total", 0),
                    "pending_inbox": pending, "last_cycle_summary": life.state().get("last_cycle_summary"),
                    "last_error": last_error,
                }
                _atomic_write(status_path, status)
                store.set_meta("runtime_status", status)
                store.db.commit()
                last_status = now
            time.sleep(max(0.5, min(float(tick_seconds), 30.0)))
        with store.lock, store.db:
            store.log("child_runtime_stopped", {"state": state, "pid": os.getpid()})
            store.set_meta("runtime_status", {"organism_id": organism_id, "state": state, "pid": os.getpid(), "last_heartbeat": time.time()})
        _atomic_write(status_path, {"organism_id": organism_id, "state": state, "pid": os.getpid(), "last_heartbeat": time.time()})
        return 0
    except BaseException as exc:
        state = "failed"
        failure = {"organism_id": organism_id, "state": state, "pid": os.getpid(), "last_heartbeat": time.time(),
                   "last_error": f"{type(exc).__name__}: {exc}"[:500], "traceback": traceback.format_exc()[-3000:]}
        try:
            _atomic_write(status_path, failure)
            if store is not None:
                with store.lock, store.db:
                    store.log("child_runtime_failed", {"error": failure["last_error"]})
                    store.set_meta("runtime_status", failure)
        except Exception:
            pass
        return 1
    finally:
        if store is not None:
            try:
                store.close()
            except Exception:
                pass


def main() -> int:
    parser = argparse.ArgumentParser(description="Run one supervised artificial-life organism.")
    parser.add_argument("--home", required=True)
    parser.add_argument("--organism-id", required=True)
    parser.add_argument("--colony-home", required=True)
    parser.add_argument("--control", required=True)
    parser.add_argument("--heartbeat", required=True)
    parser.add_argument("--supervisor-pid", required=True, type=int)
    parser.add_argument("--tick-seconds", type=float, default=3.0)
    parser.add_argument("--orphan-timeout", type=float, default=20.0)
    args = parser.parse_args()
    return run_worker(args.home, args.organism_id, args.colony_home, args.control,
                      args.heartbeat, args.supervisor_pid, args.tick_seconds, args.orphan_timeout)


if __name__ == "__main__":
    raise SystemExit(main())
