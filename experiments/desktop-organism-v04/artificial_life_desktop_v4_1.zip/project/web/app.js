const $ = (id) => document.getElementById(id);
const esc = (value) => String(value ?? '').replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
let token = sessionStorage.getItem('alife-admin-token') || '';
let latestAnswer = null;
let neuronKind = 'all';
let cachedNeurons = [];

function toast(message) {
  const el = $('toast'); el.textContent = message; el.classList.add('show');
  clearTimeout(toast.timer); toast.timer = setTimeout(() => el.classList.remove('show'), 3200);
}
async function api(path, options = {}) {
  const headers = {'Authorization': `Bearer ${token}`, ...(options.headers || {})};
  if (options.body !== undefined) headers['Content-Type'] = 'application/json';
  const res = await fetch(path, {...options, headers, body: options.body === undefined ? undefined : JSON.stringify(options.body)});
  let data;
  try { data = await res.json(); } catch { data = {error: `HTTP ${res.status}`}; }
  if (!res.ok) {
    if (res.status === 401) { logout(); }
    throw new Error(data.error || `HTTP ${res.status}`);
  }
  return data;
}
function showApp(yes) { $('loginPanel').hidden = yes; $('appPanel').hidden = !yes; }
function logout() { token=''; sessionStorage.removeItem('alife-admin-token'); showApp(false); }
function metric(value, label) { return `<div class="metric"><strong>${esc(value)}</strong><span>${esc(label)}</span></div>`; }
function item(title, body, tags = []) {
  return `<div class="item"><div class="item-title">${esc(title)}</div>${body ? `<div class="item-body">${esc(body)}</div>` : ''}${tags.length ? `<div class="tagrow">${tags.map(t=>`<span class="tag">${esc(t)}</span>`).join('')}</div>` : ''}</div>`;
}
async function connect() {
  const t = $('tokenInput').value.trim();
  if (!t) { $('loginError').textContent = 'Enter the admin token first.'; return; }
  token = t;
  try {
    await api('/api/status');
    sessionStorage.setItem('alife-admin-token', token);
    $('loginError').textContent = '';
    showApp(true);
    await refreshAll();
    toast('Connected to local organism.');
  } catch (err) { $('loginError').textContent = err.message; }
}
async function refreshAll() {
  const [status, neurons, edges, knowledge, activity] = await Promise.all([
    api('/api/status'), api('/api/neurons'), api('/api/edges'), api('/api/knowledge'), api('/api/activity')
  ]);
  renderStatus(status); cachedNeurons = neurons.neurons; renderNeurons(); renderEdges(edges.edges);
  renderKnowledge(knowledge.knowledge); renderActivity(activity.activity);
}
function renderStatus(s) {
  $('organismName').textContent = s.identity.name;
  $('runtimeLabel').textContent = s.paused ? 'Paused · persistent state' : 'Awake · local runtime';
  $('metrics').innerHTML = [
    metric(s.neurons.total, 'neurons in brain'), metric(s.knowledge_items, 'knowledge memories'),
    metric(s.relationships, 'weighted relationships'), metric(formatBytes(s.database_bytes), 'SQLite file size'),
    metric(s.resource_usage.chars_ingested.toLocaleString(), 'characters received today'), metric(s.activity_events, 'logged events')
  ].join('');
  $('neuronCountPill').textContent = `${s.neurons.total} nodes`;
  $('edgeCountPill').textContent = `${s.relationships} edges`;
  $('knowledgeCountPill').textContent = `${s.knowledge_items} items`;
  $('pauseState').textContent = s.paused ? 'Paused' : 'Running';
  $('pauseBtn').disabled = !!s.paused; $('resumeBtn').disabled = !s.paused;
  $('nameInput').value = s.identity.name;
  const used = s.resource_usage.chars_ingested;
  const pct = Math.max(0, Math.min(100, used / 100000 * 100));
  const work = s.resource_usage.work_units;
  const workPct = Math.max(0, Math.min(100, work / 10000 * 100));
  $('budgetBar').style.width = `${pct}%`;
  $('workBudgetBar').style.width = `${workPct}%`;
  $('budgetText').textContent = `${used.toLocaleString()} / 100,000 characters ingested today (${pct.toFixed(1)}%). Per-input maximum: 20,000 characters. Work units: ${work.toLocaleString()} / 10,000 today (${workPct.toFixed(1)}%); queries: ${s.resource_usage.queries}.`;
  $('llmHint').textContent = s.capabilities?.local_llm ? 'Configured model: ' + s.capabilities.local_llm_model : 'Set ALIFE_OLLAMA_MODEL and restart to enable';
  $('useLlm').disabled = !s.capabilities?.local_llm;
}
function formatBytes(n) { if (n < 1024) return `${n} B`; if (n < 1024*1024) return `${(n/1024).toFixed(1)} KB`; return `${(n/(1024*1024)).toFixed(2)} MB`; }
function renderNeurons() {
  const filtered = cachedNeurons.filter(n => neuronKind === 'all' || n.kind === neuronKind);
  $('neuronsList').innerHTML = filtered.length ? filtered.map(n => item(`#${n.id} · ${n.label}`, `strength ${Number(n.strength).toFixed(2)} · activations ${n.activation_count} · created ${new Date(n.created_at*1000).toLocaleString()}`, [n.kind, `${n.terms.length} terms`, `key ${n.neuron_key.slice(0,18)}`])).join('') : '<p class="muted">No neurons yet. Feed the organism some information.</p>';
}
function renderEdges(edges) {
  $('edgesList').innerHTML = edges.length ? edges.slice(0,100).map(e => item(`${e.source_label} ↔ ${e.target_label}`, `weight ${Number(e.weight).toFixed(2)} · seen ${e.seen_count}`, [e.relation, `#${e.source_id} → #${e.target_id}`])).join('') : '<p class="muted">Connections will grow as concepts co-occur in memories.</p>';
}
function renderKnowledge(rows) {
  $('knowledgeList').innerHTML = rows.length ? rows.map(k => item(k.text, `source: ${k.source} · seen ${k.seen_count} · feedback ${Number(k.feedback).toFixed(1)} · ${new Date(k.last_seen*1000).toLocaleString()}`, [`memory #${k.id}`, ...k.terms.slice(0,6)])).join('') : '<p class="muted">No knowledge stored. Feed a note or document excerpt above.</p>';
}
function renderActivity(rows) {
  $('activityList').innerHTML = rows.length ? rows.map(a => {
    let detail = a.detail; if (typeof detail === 'string') { try { detail=JSON.parse(detail); } catch { detail={}; } }
    const parts = Object.entries(detail || {}).slice(0,5).map(([k,v])=>`${k}: ${typeof v === 'object' ? JSON.stringify(v) : v}`).join(' · ');
    return item(a.event, parts, [new Date(a.timestamp*1000).toLocaleTimeString()]);
  }).join('') : '<p class="muted">Activity will appear here.</p>';
}
async function learn() {
  const text = $('learnText').value;
  $('learnResult').textContent = 'Learning...'; $('learnBtn').disabled = true;
  try {
    const r = await api('/api/learn', {method:'POST', body:{text, source:$('sourceInput').value || 'owner'}});
    const x = r.result;
    $('learnResult').textContent = `Stored ${x.new_knowledge} new memories; ${x.duplicate_statements} repeated statements reinforced; grew ${x.new_memory_neurons} memory neurons and ${x.new_concept_neurons} concept neurons. Updated ${x.edge_updates} relationships.`;
    $('learnText').value=''; $('charCount').textContent='0 / 20,000 characters';
    await refreshAll(); toast('Information assimilated into persistent memory.');
  } catch (err) { $('learnResult').textContent = err.message; }
  finally { $('learnBtn').disabled = false; }
}
async function ask() {
  $('askResult').textContent = 'Retrieving memories...'; $('askBtn').disabled = true; $('answerBox').hidden = true;
  try {
    const r = await api('/api/ask', {method:'POST', body:{question:$('questionInput').value, use_local_llm:$('useLlm').checked}});
    latestAnswer = r.result;
    $('answerText').textContent = latestAnswer.answer;
    $('answerMethod').textContent = latestAnswer.method;
    $('evidence').innerHTML = latestAnswer.evidence.length ? '<h3>Supporting memories</h3>' + latestAnswer.evidence.map(e=>`<div class="evidence"><div class="meta">Memory #${esc(e.id)} · ${esc(e.source)} · relevance ${esc(e.score)}</div><p>${esc(e.text)}</p></div>`).join('') : '<p class="muted">No retrieved evidence. Feed relevant information to improve future answers.</p>';
    $('feedbackButtons').hidden = !latestAnswer.evidence.length;
    $('feedbackStatus').textContent = latestAnswer.model_note ? `Local model unavailable; used fallback: ${latestAnswer.model_note}` : '';
    $('answerBox').hidden = false; $('askResult').textContent='';
    await refreshAll();
  } catch (err) { $('askResult').textContent = err.message; }
  finally { $('askBtn').disabled = false; }
}
async function sendFeedback(helpful) {
  if (!latestAnswer) return;
  try {
    const ids = latestAnswer.evidence.map(e=>e.id);
    const r = await api('/api/feedback', {method:'POST', body:{knowledge_ids:ids, helpful}});
    $('feedbackStatus').textContent = `Feedback recorded for ${r.changed} memories. ${helpful ? 'Their retrieval rank was nudged up.' : 'Their retrieval rank was nudged down.'}`;
    await refreshAll();
  } catch (err) { $('feedbackStatus').textContent = err.message; }
}
async function setPause(paused) {
  try { await api(paused?'/api/pause':'/api/resume', {method:'POST', body:{}}); await refreshAll(); toast(paused?'Organism paused.':'Organism resumed.'); }
  catch(err) { toast(err.message); }
}
async function rename() {
  try { await api('/api/rename', {method:'POST', body:{name:$('nameInput').value}}); await refreshAll(); toast('Identity updated.'); }
  catch(err) { toast(err.message); }
}
$('connectBtn').addEventListener('click', connect);
$('tokenInput').addEventListener('keydown', e=>{if(e.key==='Enter')connect();});
$('learnBtn').addEventListener('click', learn); $('askBtn').addEventListener('click', ask);
$('learnText').addEventListener('input', ()=>{$('charCount').textContent=`${$('learnText').value.length.toLocaleString()} / 20,000 characters`;});
$('helpfulBtn').addEventListener('click', ()=>sendFeedback(true)); $('unhelpfulBtn').addEventListener('click', ()=>sendFeedback(false));
$('pauseBtn').addEventListener('click', ()=>setPause(true)); $('resumeBtn').addEventListener('click', ()=>setPause(false));
$('refreshBtn').addEventListener('click', ()=>refreshAll().then(()=>toast('View refreshed.')).catch(e=>toast(e.message)));
$('renameBtn').addEventListener('click', rename);
document.querySelectorAll('[data-kind]').forEach(b=>b.addEventListener('click', ()=>{neuronKind=b.dataset.kind;document.querySelectorAll('[data-kind]').forEach(x=>x.classList.toggle('selected',x===b));renderNeurons();}));
if (token) { $('tokenInput').value=token; connect(); }
