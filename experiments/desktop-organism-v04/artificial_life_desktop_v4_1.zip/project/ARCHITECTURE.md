# Artificial Life Desktop — v0.4.0 Architecture

## Runtime shape

```text
                 Native floating desktop pet
                 draggable, always-on-top body
                            |
                       Brain Console
       Life / Mind / Knowledge / Ask / Network / Activity
                            |
                     Agency workbench
       Goals / Predictions / Files / Colony / Neural core
                            |
                  Organism orchestration layer
         +------------------+--------------------+
         |                  |                    |
   Symbolic memory      Recurrent core      Local services
   & concept graph      24-unit RNN-ish      goals / files /
   + spreading act.     state + Oja rule    predictions/colony
         |                  |                    |
         +----------- evidence/retrieval --------+
                            |
             Optional local Ollama integrations
             embeddings and response generation
                            |
                  SQLite / logs / backups
```

## Symbolic knowledge network

- A **memory record/neuron** represents one normalized statement and retains a SHA-256 digest, source label, timestamps, count and feedback.
- A **concept record/neuron** represents an extracted lexical term.
- Edges include containment, co-occurrence, heuristic association and potential conflict.
- A query can spread activation through positive edges for up to three hops; potential-conflict edges do not count as supporting evidence.
- Retrieval combines lexical match, activation, optional cached semantic similarity, low-weight recurrent response similarity, feedback and repetition. Evidence text and source remain visible so scores are inspectable.
- The contradiction detector is heuristic and retains both sources. It is not a complete rule engine.

## Adaptive recurrent substrate

`organism/dynamics.py` stores a 24-unit hidden state and bounded input/recurrent weight matrices in SQLite metadata. Text is converted into deterministic hashed lexical features. Three recurrent micro-steps produce an activation vector; learned text applies a local Oja-style update, clamped to a bounded range. Queries run an inference-only pass and can produce a low-weight recurrent resonance proxy for candidate ranking.

The subsystem is intentionally small, randomly initialized and has no pretrained language representation or gradient-based language objective. This proves only that state and weights adapt under a local rule. It does not establish semantic comprehension or consciousness.

## Optional local semantic memory

`organism/semantic.py` calls the Ollama `/api/embed` endpoint at `127.0.0.1:11434` only when `ALIFE_OLLAMA_EMBED_MODEL` is set. Vectors are cached by memory digest and model in SQLite. The Neural core panel indexes up to 100 missing vectors per click. Cached vector cosine similarity may retrieve relevant memories with weaker word overlap. If the local model is unreachable or cache is not populated, the graph/lexical methods remain available. No hosted endpoint is configured.

## Goal and prediction systems

- `GoalManager` persists titles, success criteria, priority, status, notes and timestamps. It sorts pending/in-progress goals. It does not execute tasks on its own.
- `PredictionEngine` stores context, expected outcome, self-reported confidence and a later observation. The current error score is a transparent token-overlap proxy and must not be interpreted as calibrated forecast accuracy.
- The older unresolved-question queue remains a separate retrieval aid.

## File permission boundary

`PermissionedFiles` requires explicit per-file grants. Only a fixed allowlist of textual extensions can be ingested, under a bounded file-size limit. Grant, ingestion and revocation are separate actions. Revocation prevents future reads through this feature; it does not delete facts learned from the file. No broad crawling, active screen capture or arbitrary file access is enabled.

## Colony and messaging

`Colony` creates individual SQLite homes and identities with parent and generation metadata. Knowledge inheritance is opt-in and limited to 500 statements. The running primary organism is registered in the creator console along with child profiles. The UI supports send-to-selected and broadcast. Each local inbox envelope is Fernet-encrypted and authenticated using a shared symmetric key stored in `colony/colony.key`; key permissions are restricted to owner-only on POSIX where possible.

Security boundary: the key is local and shared by the colony, and same-account compromise can expose it. There is no network transport, per-agent key exchange, independent sender signatures, key rotation, or replay defense. Do not describe this as secure inter-host messaging.

Each child has its own database and identity but does not yet run a simultaneous independent desktop overlay or cognition loop. The creator console is a local controller, not a distributed orchestration service.

## Runtime safety, resource monitoring and recovery

Application-level controls bound ingestion size, query size, daily characters/work and daily reflection cycles. If `psutil` is installed, `RuntimeGuard` observes process RSS/CPU and pauses background cognitive work for a cooldown when configured soft thresholds are exceeded. It does not terminate the app or enforce an OS-level quota. The organism avoids arbitrary shell execution and model output is never executed as code.

The SQLite store uses WAL mode. Rotating runtime logs and fatal traceback logs support diagnosis. Consistent SQLite backups are created periodically and at orderly shutdown; backup files are checked with SQLite `quick_check`, and the three most recent snapshots are retained. This is useful recovery support, not a guarantee against every crash or disk failure.

## Persistent data

The default `data/` folder holds the main database, a `colony/` directory, runtime logs and backups. Set `ALIFE_HOME` to choose another home. Do not put the folder on an untrusted shared filesystem because it contains memory, inbox metadata, and the colony encryption key.

## Consciousness boundary

This architecture includes persistent memory, an adaptive internal state, goal records, prediction/outcome comparison and multiple information pathways. Those mechanisms may support experiments in machine cognition. There is no accepted engineering recipe or validated behavioral test that establishes subjective experience; passing software tests must not be described as proof of consciousness.


## v0.4.0 — supervised colony process lifecycle

Each non-primary organism can run through `organism.worker` as a separate Python process. `ColonyRuntimeSupervisor` persists desired states, writes per-organism controls atomically, polls child processes, publishes a heartbeat, and restarts unexpected exits with a rolling restart cap. Workers own their SQLite connection and cognitive loop. On parent shutdown the children receive a shutdown control; their desired state is preserved, so active children can relaunch next time the desktop app starts. If the owner dies without shutting down, workers exit after the supervisor heartbeat expires.

Workers update a per-organism `runtime_status.json` with PID, last heartbeat, cycles, reflections, neuron/memory counts and pending inbox count. The Colony UI presents lifecycle status and actions. The primary organism remains embedded in the desktop UI process. Child inbox messages remain untrusted data; workers count them but do not execute them.

Windows validation scripts are provided in `scripts/validate_windows.ps1` and `scripts/windows_desktop_smoke.py`, and a native Windows GitHub Actions workflow is provided in `.github/workflows/windows-desktop-validation.yml`. Unless the workflow log shows a completed pass on a Windows runner, native Windows validation must be reported as pending.
