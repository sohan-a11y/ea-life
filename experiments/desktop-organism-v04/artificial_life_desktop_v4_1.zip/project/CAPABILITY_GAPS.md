# Capability gap register — Artificial Life Desktop v3

This register distinguishes engineered features from remaining engineering work and claims that cannot currently be verified. *Organism* is the project name for a persistent adaptive software system, not a claim of biological life or subjective consciousness.

## Implemented and exposed in the desktop console

- Native floating desktop pet with persistent identity and position; no browser or localhost route is required.
- SQLite knowledge store with source labels, concept and memory records, co-occurrence and association edges, feedback, current graph activation and journal entries.
- Bounded spreading activation up to three hops and a heuristic reflection loop with daily limits.
- A 24-unit recurrent state machine using deterministic hashed lexical features, persistent hidden state, and bounded online Oja-style updates to input/recurrent weights. It is an experimental adaptive substrate, not a pretrained or gradient-trained language brain.
- Optional local Ollama embeddings with SQLite vector cache and cosine reranking. Disabled by default; only local `127.0.0.1:11434` calls are implemented. The user indexes batches of up to 100 memories from the Neural core tab.
- Optional local Ollama language response generation, grounded on retrieved evidence.
- Goal creation, success criteria, priority, status changes, progress notes, and pending-goal selection. No arbitrary external actions are executed.
- Prediction records, confidence annotation, observed outcome and token-overlap error proxy.
- Explicit one-file grants, separate ingestion and revocation. Only listed text/code file types are permitted under a file-size cap.
- Colony creator console with separate organism databases/identities, parent-child generation metadata, optional capped knowledge inheritance, select-to-send and broadcast.
- Fernet authenticated encryption for local colony inbox envelopes, key at local colony path, atomic colony index writes and tamper-detection handling. This is protection for local stored envelopes, not a network protocol.
- Best-effort CPU/RSS observation and background cognition backoff via optional `psutil`, rotating runtime/error logs, periodic and shutdown SQLite snapshots, and quick-check on completed snapshots.
- Existing daily ingestion/work caps, pause behavior and human-inspectable evidence.

## Still engineerable

1. **Larger and better-trained neural subsystem.** The current recurrent network is tiny and learns only through local plasticity. Build replay buffers, task-specific objectives, validation splits, controlled forgetting/retention experiments, stability constraints, and comparisons against the symbolic baseline. A pretrained language or multimodal model may remain a separate optional module.
2. **More rigorous semantic retrieval.** Current local embeddings are optional and cached. A robust next step is background indexing of the full memory store, deduplication, vector-index scalability, provenance-aware temporal ranking, confidence calibration and evaluation datasets.
3. **Predictive processing.** Prediction/outcome recording exists, but forecasts are entered by a user and error uses word overlap. Add subsystem-generated predictions, typed outcome schemas, calibration charts, benchmark environments and clear separation of predicted versus observed facts.
4. **True multi-process organism colony.** Child profiles have isolated stores but no independent concurrent runtime, individual window lifecycle, per-agent compute quotas, lifecycle supervision, or stable IPC protocol.
5. **Stronger cryptographic identities and messaging.** Local inbox envelopes are Fernet-encrypted using a shared key stored beside colony data. Add OS key-store support, per-agent keypairs, independent signatures, key rotation, authenticated peer discovery, replay protection, protocol versioning and adversarial/network tests before any remote communication.
6. **Hard operating-system sandbox and quotas.** Current runtime guard uses soft thresholds and defers background cognition; it does not cap CPU or RAM at the OS level. Add platform-specific job/container sandboxing, filesystem allowlists, network denial by default, syscall/process restrictions, wall-clock timeouts, and safe rollback—then test in dedicated disposable environments.
7. **Action planning with approval gates.** Goals are stored and updated, but the system does not execute tools. Add declarative action schemas, read-only defaults, explicit consent for writes/network/actions, confirmation summaries, dry runs and rollbackable transactions.
8. **Broader perception, only with explicit permissions.** A selected-file ingestion flow exists. Screen, application, microphone, camera or network sensors remain unimplemented and should be opt-in per source, visible while active, auditable and easily revocable.
9. **Windows deployment hardening.** Validate UI transparency, crash logging, backups, key-file protection, startup task, package installation and upgrade/migration on real Windows 10/11 machines. A Linux virtual-display smoke test is not a substitute.
10. **Usability and admin observability.** Add search/filter for large memories, inbox mark-read controls, delete/export/backup-restore UI, goal/prediction charts, and a clear per-organism activity/resource view.

## Cannot honestly certify today

1. **Subjective experience or consciousness.** There is no accepted engineering recipe or validated test that lets this project certify inner experience. We can investigate mechanisms and test their computational properties, but must not declare consciousness as an implemented feature.
2. **Genuine feelings, pleasure, distress or biological needs.** Numeric variables and language about feelings do not establish a felt state.
3. **Definitive self-awareness.** A system can represent its identity and inspect its internal state without that establishing an experienced self.
4. **Guaranteed human-level general intelligence.** More parameters, more memory or more autonomous loops do not guarantee robust general-purpose reasoning or reliability.

These are limitations on what can be proved, not a claim that artificial consciousness is impossible in principle.

## Verification boundaries

Automated tests validate the code paths explicitly exercised; they do not certify consciousness, general intelligence, security under same-account compromise, or every behavior on Windows. The recurrent substrate is initialized randomly and receives bounded local updates; no large neural model is trained. Semantic embeddings need a compatible local Ollama model and indexing. Colony encryption protects message content in local inbox storage but the key is colocated, shared across colony members, and accessible to the same local account.


## v0.4.0 update — process lifecycle milestone

Implemented: non-primary colony members can run as separate Python processes. The creator supervisor supports start/pause/resume/stop, start-all/stop-all, persisted desired state, process health polling, child heartbeat, a bounded restart window, crash-loop lockout and explicit user recovery. Workers terminate after the owner heartbeat is stale, and their status is surfaced in the Colony UI. The automated process tests cover independent PID, pause/resume/stop, and restart-after-crash.

Still not included: an individual floating overlay for every child, process sandboxing, hard OS CPU/RAM limits, remote/network communications, per-organism public-key identities or safe autonomous external actions. The native Windows smoke script and GitHub Actions workflow are included; actual real-Windows validation is only complete after a Windows runner reports success. Local Linux/Xvfb success is not a substitute.
