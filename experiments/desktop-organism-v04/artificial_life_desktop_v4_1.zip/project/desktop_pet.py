"""Native floating desktop companion for the local artificial-life prototype.

The pet is a visual interface to a persistent software organism. Its animation
states are UI indicators, not evidence of sentience or feelings.
"""
from __future__ import annotations

import json
import os
import platform
import time
import sys
import logging
import faulthandler
from logging.handlers import RotatingFileHandler
import tkinter as tk
from tkinter import ttk, messagebox, filedialog
from pathlib import Path

from organism.brain import Brain
from organism.life import LifeController
from organism.resources import ResourceLimits
from organism.store import OrganismStore
from organism.goals import GoalManager
from organism.prediction import PredictionEngine
from organism.permissions import PermissionedFiles
from organism.colony import Colony
from organism.runtime_guard import RuntimeGuard
from organism.runtime_supervisor import ColonyRuntimeSupervisor

ROOT_DIR = Path(__file__).resolve().parent
DATA_DIR = Path(os.environ.get("ALIFE_HOME", str(ROOT_DIR / "data"))).resolve()
try:
    VERSION = (ROOT_DIR / "VERSION").read_text(encoding="utf-8").strip()
except OSError:
    VERSION = "0.4.0"
TRANSPARENT = "#ff00ff"


class DesktopPet:
    def __init__(self, store: OrganismStore, brain: Brain):
        self.store, self.brain = store, brain
        self.life = LifeController(store, brain)
        self.goal_manager = GoalManager(store)
        self.prediction_engine = PredictionEngine(store)
        self.permissioned_files = PermissionedFiles(brain, store)
        self.colony = Colony(DATA_DIR / "colony")
        self.colony.register_existing(store.home, store.get_meta("identity"))
        self.runtime_supervisor = ColonyRuntimeSupervisor(self.colony, project_root=ROOT_DIR)
        self.runtime_supervisor.start()
        self.runtime_guard = RuntimeGuard(store, store.home)
        self._last_backup_at = time.time()
        self._last_resource_sample = {}
        self.root = tk.Tk(className="ArtificialLifePet")
        self.root.report_callback_exception = self._report_callback_exception
        self.root.title(f"Artificial Life Pet v{VERSION}")
        self.root.resizable(False, False)
        self.root.attributes("-topmost", True)
        self._windows_transparency = False
        if platform.system() == "Windows":
            try:
                self.root.configure(bg=TRANSPARENT)
                self.root.wm_attributes("-transparentcolor", TRANSPARENT)
                self._windows_transparency = True
            except tk.TclError:
                pass
        if not self._windows_transparency:
            try:
                self.root.attributes("-alpha", 0.96)
            except tk.TclError:
                pass
        self.root.overrideredirect(True)
        self.canvas = tk.Canvas(self.root, width=205, height=220, bg=TRANSPARENT, highlightthickness=0, bd=0)
        self.canvas.pack()
        self.panel = None
        self.state = "idle"
        self.status_line = "Here, and ready to learn"
        self._drag = None
        self._blink = False
        self._frame = 0
        self._geometry = self.store.get_meta("pet_geometry")
        if not self._geometry:
            sw, sh = self.root.winfo_screenwidth(), self.root.winfo_screenheight()
            self._geometry = {"x": max(20, sw - 250), "y": 100}
        self.root.geometry(f"205x220+{self._geometry['x']}+{self._geometry['y']}")
        self.canvas.bind("<ButtonPress-1>", self._start_drag)
        self.canvas.bind("<B1-Motion>", self._drag_pet)
        self.canvas.bind("<ButtonRelease-1>", self._end_drag)
        self.canvas.bind("<Double-Button-1>", lambda _e: self.show_panel())
        self.canvas.bind("<Button-3>", self._context_menu)
        self.root.protocol("WM_DELETE_WINDOW", self.close)
        self._draw()
        self.root.after(350, self._animate)
        self.root.after(1200, self._refresh_runtime)
        self.root.after(2000, self._poll_colony_runtimes)
        self.root.after(15000, self._life_cycle)
        self.root.after(650, self._first_run_hint)

    def _first_run_hint(self):
        if not self.store.get_meta("pet_hint_seen", False):
            self.store.set_meta("pet_hint_seen", True)
            self.store.log("desktop_pet_started", {"platform": platform.system()})
            self.store.db.commit()
            self.show_panel()

    def _start_drag(self, event):
        self._drag = (event.x_root, event.y_root, self.root.winfo_x(), self.root.winfo_y())

    def _drag_pet(self, event):
        if not self._drag:
            return
        sx, sy, wx, wy = self._drag
        x, y = wx + event.x_root - sx, wy + event.y_root - sy
        self.root.geometry(f"205x220+{x}+{y}")

    def _end_drag(self, _event):
        if self._drag:
            self._drag = None
            self.store.set_meta("pet_geometry", {"x": self.root.winfo_x(), "y": self.root.winfo_y()})
            self.store.db.commit()

    def _context_menu(self, event):
        menu = tk.Menu(self.root, tearoff=False)
        menu.add_command(label="Open brain & feed pet", command=self.show_panel)
        menu.add_command(label="Pause organism" if not self.store.get_meta("paused", False) else "Resume organism", command=self.toggle_pause)
        menu.add_separator()
        menu.add_command(label="Exit pet", command=self.close)
        try:
            menu.tk_popup(event.x_root, event.y_root)
        finally:
            menu.grab_release()

    def _draw(self):
        c = self.canvas
        c.delete("all")
        if self._windows_transparency:
            c.configure(bg=TRANSPARENT)
        else:
            c.configure(bg="#121d2a")
        # small speech bubble
        identity = self.store.get_meta("identity") or {"name": "Organism"}
        name = identity.get("name", "Organism")[:18]
        bubble = self.status_line[:25]
        c.create_rectangle(16, 10, 189, 47, fill="#16283b", outline="#304a5e", width=1)
        c.create_text(102, 22, text=name, fill="#f4f8fb", font=("Segoe UI", 10, "bold"))
        c.create_text(102, 36, text=bubble, fill="#a9c4d8", font=("Segoe UI", 8))
        # shadow, feet and pixel-inspired body
        bob = 2 if self._frame % 2 else 0
        c.create_oval(38, 181, 166, 203, fill="#142330", outline="")
        c.create_rectangle(58, 157 + bob, 77, 184 + bob, fill="#4cc7a0", outline="#226d5b")
        c.create_rectangle(126, 157 + bob, 145, 184 + bob, fill="#4cc7a0", outline="#226d5b")
        c.create_rectangle(40, 91 + bob, 164, 161 + bob, fill="#46d6a7", outline="#1d7c67", width=3)
        c.create_rectangle(51, 72 + bob, 153, 151 + bob, fill="#46d6a7", outline="#1d7c67", width=2)
        c.create_rectangle(61, 62 + bob, 143, 139 + bob, fill="#54e2b6", outline="#1d7c67", width=2)
        c.create_rectangle(43, 103 + bob, 59, 142 + bob, fill="#31b88f", outline="#1d7c67")
        c.create_rectangle(145, 103 + bob, 161, 142 + bob, fill="#31b88f", outline="#1d7c67")
        # eyes blink briefly; expressions reflect runtime state only
        eye_y = 91 + bob
        if self._blink:
            c.create_rectangle(72, eye_y, 89, eye_y + 4, fill="#103047", outline="")
            c.create_rectangle(113, eye_y, 130, eye_y + 4, fill="#103047", outline="")
        else:
            c.create_rectangle(72, eye_y, 89, eye_y + 17, fill="#103047", outline="")
            c.create_rectangle(113, eye_y, 130, eye_y + 17, fill="#103047", outline="")
            c.create_rectangle(76, eye_y + 3, 80, eye_y + 7, fill="#eaffff", outline="")
            c.create_rectangle(117, eye_y + 3, 121, eye_y + 7, fill="#eaffff", outline="")
        mouth = {"learning": "▰", "curious": "◇", "resting": "ᴗ", "paused": "—", "idle": "⌣"}.get(self.state, "⌣")
        c.create_text(102, 127 + bob, text=mouth, fill="#104e47", font=("Segoe UI", 17, "bold"))
        # small badge indicates organism state
        colors = {"learning": "#ffcf70", "curious": "#9dc9ff", "resting": "#a5b1bf", "paused": "#ff8a86", "idle": "#69e5b5"}
        color = colors.get(self.state, "#69e5b5")
        c.create_oval(153, 56, 174, 77, fill="#14283a", outline="#385469")
        c.create_oval(159, 62, 168, 71, fill=color, outline="")
        c.create_text(102, 207, text="double-click to open brain  •  right-click for menu", fill="#bed1de" if not self._windows_transparency else "#315064", font=("Segoe UI", 7))

    def _animate(self):
        self._frame += 1
        self._blink = self._frame % 17 == 0
        if self.state not in ("learning", "paused"):
            self.state = "curious" if self._frame % 10 in (0, 1) else ("resting" if self._frame % 30 in (14, 15, 16) else "idle")
        self._draw()
        self.root.after(550, self._animate)

    def _refresh_runtime(self):
        try:
            if self.store.get_meta("paused", False):
                self.state, self.status_line = "paused", "Runtime paused"
            else:
                stats = self.store.status()
                self.state = "idle"
                self.status_line = f"{stats['neurons']['total']} neurons · {stats['knowledge_items']} memories"
            if self.panel and self.panel.winfo_exists():
                self._update_dashboard_stats()
        except Exception as exc:
            self.status_line = f"Runtime issue: {str(exc)[:18]}"
        self._draw()
        self.root.after(4000, self._refresh_runtime)

    def _report_callback_exception(self, exc_type, exc_value, traceback):
        logging.getLogger("alife.desktop").error("Unhandled UI callback exception", exc_info=(exc_type, exc_value, traceback))
        try:
            self.store.log("ui_callback_exception", {"type": getattr(exc_type, "__name__", str(exc_type)), "error": str(exc_value)[:240]})
            self.store.db.commit()
        except Exception:
            pass

    def _label(self, parent, text, **kwargs):
        return ttk.Label(parent, text=text, **kwargs)

    def show_panel(self):
        if self.panel and self.panel.winfo_exists():
            self.panel.deiconify(); self.panel.lift(); self.panel.focus_force(); return
        p = tk.Toplevel(self.root)
        self.panel = p
        p.title(f"Artificial Life · Brain Console · v{VERSION}")
        p.geometry("960x760")
        p.minsize(820, 640)
        p.attributes("-topmost", True)
        p.configure(bg="#101922")
        p.protocol("WM_DELETE_WINDOW", p.withdraw)
        style = ttk.Style(p)
        try: style.theme_use("clam")
        except tk.TclError: pass
        style.configure("TFrame", background="#101922")
        style.configure("TLabel", background="#101922", foreground="#e9f0f6", font=("Segoe UI", 10))
        style.configure("Title.TLabel", font=("Segoe UI", 18, "bold"), foreground="#65e1b4")
        style.configure("Sub.TLabel", foreground="#95aaba")
        style.configure("TButton", padding=6)
        style.configure("TNotebook", background="#101922", borderwidth=0)
        style.configure("TNotebook.Tab", padding=(13, 7))
        outer = ttk.Frame(p, padding=16); outer.pack(fill="both", expand=True)
        identity = self.store.get_meta("identity")
        header = ttk.Frame(outer); header.pack(fill="x")
        ttk.Label(header, text="YOUR ARTIFICIAL ORGANISM", style="Title.TLabel").pack(anchor="w")
        self.name_var = tk.StringVar(value=identity.get("name", "Aurelia"))
        namebar = ttk.Frame(header); namebar.pack(fill="x", pady=(6, 2))
        ttk.Label(namebar, text="Name").pack(side="left")
        ttk.Entry(namebar, textvariable=self.name_var, width=22).pack(side="left", padx=8)
        ttk.Button(namebar, text="Rename", command=self.rename).pack(side="left")
        self.stats_var = tk.StringVar(value="Starting…")
        ttk.Label(header, textvariable=self.stats_var, style="Sub.TLabel").pack(anchor="w", pady=(4, 10))
        toolbar = ttk.Frame(header); toolbar.pack(fill="x", pady=(0, 8))
        ttk.Button(toolbar, text="Pause organism" if not self.store.get_meta("paused", False) else "Resume organism", command=self.toggle_pause).pack(side="left")
        ttk.Button(toolbar, text="Refresh", command=self.refresh_all).pack(side="left", padx=6)
        ttk.Label(toolbar, text="Bounded background reflection only; no autonomous file crawling.", style="Sub.TLabel").pack(side="left", padx=10)
        self.tabs = ttk.Notebook(outer); self.tabs.pack(fill="both", expand=True)
        self._build_life_tab(); self._build_mind_tab(); self._build_learn_tab(); self._build_ask_tab(); self._build_neurons_tab(); self._build_activity_tab(); self._build_agency_tab()
        self.refresh_all()

    def _build_life_tab(self):
        tab = ttk.Frame(self.tabs, padding=14); self.tabs.add(tab, text="Life")
        self._label(tab, "What counts as food?", style="Title.TLabel").pack(anchor="w")
        self._label(tab, "Information you choose to give it. CPU time and daily work units are its bounded energy budget.").pack(anchor="w", pady=(4, 12))
        self.life_text = tk.Text(tab, height=7, wrap="word", bg="#172531", fg="#e9f0f6", insertbackground="white", relief="flat", padx=10, pady=10)
        self.life_text.pack(fill="x")
        self.life_text.insert("1.0", "I am a software organism. I persist by saving my identity and knowledge. I grow concept neurons when I learn new information.")
        ttk.Button(tab, text="Feed organism", command=self.feed_life).pack(anchor="w", pady=8)
        self.learn_result = tk.StringVar(value="Feed it a few facts to see neuron and memory counts grow.")
        self._label(tab, "", textvariable=self.learn_result, wraplength=680).pack(anchor="w", pady=4)
        self.life_stats = tk.StringVar(value="")
        self._label(tab, "", textvariable=self.life_stats, wraplength=680).pack(anchor="w", pady=6)

    def _build_mind_tab(self):
        tab = ttk.Frame(self.tabs, padding=14); self.tabs.add(tab, text="Mind")
        self._label(tab, "Internal state & self-model", style="Title.TLabel").pack(anchor="w")
        self._label(tab, "These are measurable software control variables and a report of implemented capabilities—not claims of feelings or consciousness.", style="Sub.TLabel", wraplength=680).pack(anchor="w", pady=(3, 8))
        self.mind_state_var = tk.StringVar(value="Initializing internal controls…")
        self._label(tab, "", textvariable=self.mind_state_var, wraplength=680).pack(anchor="w", pady=(0, 8))
        actions = ttk.Frame(tab); actions.pack(anchor="w", pady=(0, 8))
        ttk.Button(actions, text="Run one bounded reflection cycle", command=self.run_reflection).pack(side="left")
        ttk.Button(actions, text="Refresh self-model", command=self._refresh_mind).pack(side="left", padx=6)
        self._label(tab, "Self-model / implementation report", style="Sub.TLabel").pack(anchor="w")
        self.self_model_box = tk.Text(tab, height=17, wrap="word", bg="#172531", fg="#e9f0f6", relief="flat", padx=10, pady=10, state="disabled")
        self.self_model_box.pack(fill="both", expand=True, pady=(6, 0))

    def _build_learn_tab(self):
        tab = ttk.Frame(self.tabs, padding=14); self.tabs.add(tab, text="Knowledge")
        self._label(tab, "Feed it notes, concepts, or documentation", style="Title.TLabel").pack(anchor="w")
        self._label(tab, "No web crawling happens in this version. Text is stored locally with its source label.", style="Sub.TLabel").pack(anchor="w", pady=(4, 8))
        self._label(tab, "Source label").pack(anchor="w")
        self.source_var = tk.StringVar(value="owner")
        ttk.Entry(tab, textvariable=self.source_var).pack(fill="x", pady=(2, 8))
        self.knowledge_text = tk.Text(tab, height=15, wrap="word", bg="#172531", fg="#e9f0f6", insertbackground="white", relief="flat", padx=10, pady=10)
        self.knowledge_text.pack(fill="both", expand=True)
        ttk.Button(tab, text="Ingest and grow neurons", command=self.learn_knowledge).pack(anchor="w", pady=10)
        self.knowledge_result = tk.StringVar(value="")
        self._label(tab, "", textvariable=self.knowledge_result, wraplength=680).pack(anchor="w")

    def _build_ask_tab(self):
        tab = ttk.Frame(self.tabs, padding=14); self.tabs.add(tab, text="Ask")
        self._label(tab, "Ask your organism", style="Title.TLabel").pack(anchor="w")
        self.question = tk.Text(tab, height=3, wrap="word", bg="#172531", fg="#e9f0f6", insertbackground="white", relief="flat", padx=10, pady=10)
        self.question.pack(fill="x", pady=(8, 6))
        self.use_llm = tk.BooleanVar(value=False)
        model = os.environ.get("ALIFE_OLLAMA_MODEL", "").strip()
        ttk.Checkbutton(tab, text=f"Use local Ollama model ({model or 'not configured'})", variable=self.use_llm).pack(anchor="w")
        ttk.Button(tab, text="Think from memory", command=self.ask).pack(anchor="w", pady=8)
        self.answer = tk.Text(tab, height=12, wrap="word", bg="#172531", fg="#e9f0f6", relief="flat", padx=10, pady=10, state="disabled")
        self.answer.pack(fill="both", expand=True, pady=(2, 6))
        self.answer_ids = []
        feedback = ttk.Frame(tab); feedback.pack(anchor="w")
        ttk.Button(feedback, text="Helpful evidence", command=lambda: self.feedback(True)).pack(side="left")
        ttk.Button(feedback, text="Not helpful", command=lambda: self.feedback(False)).pack(side="left", padx=6)
        self.answer_note = tk.StringVar(value="Responses show which stored statements were retrieved.")
        self._label(tab, "", textvariable=self.answer_note, style="Sub.TLabel", wraplength=680).pack(anchor="w", pady=4)

    def _build_neurons_tab(self):
        tab = ttk.Frame(self.tabs, padding=14); self.tabs.add(tab, text="Neurons")
        self._label(tab, "Growing knowledge network", style="Title.TLabel").pack(anchor="w")
        self._label(tab, "Memory neurons represent stored statements; concept neurons represent extracted terms. Edges record containment and co-occurrence.", style="Sub.TLabel", wraplength=680).pack(anchor="w", pady=(3, 8))
        self.neurons_box = tk.Text(tab, wrap="word", bg="#172531", fg="#e9f0f6", relief="flat", padx=10, pady=10, state="disabled")
        self.neurons_box.pack(fill="both", expand=True)

    def _build_activity_tab(self):
        tab = ttk.Frame(self.tabs, padding=14); self.tabs.add(tab, text="Activity")
        self._label(tab, "Persistent activity journal", style="Title.TLabel").pack(anchor="w")
        self.activity_box = tk.Text(tab, wrap="word", bg="#172531", fg="#e9f0f6", relief="flat", padx=10, pady=10, state="disabled")
        self.activity_box.pack(fill="both", expand=True, pady=(8, 0))

    def _build_agency_tab(self):
        tab = ttk.Frame(self.tabs, padding=8); self.tabs.add(tab, text="Agency")
        self.agency_tabs = ttk.Notebook(tab); self.agency_tabs.pack(fill="both", expand=True)
        self._build_goals_tab()
        self._build_predictions_tab()
        self._build_files_tab()
        self._build_colony_tab()
        self._build_dynamics_tab()

    def _build_goals_tab(self):
        tab = ttk.Frame(self.agency_tabs, padding=12); self.agency_tabs.add(tab, text="Goals")
        self._label(tab, "Persistent goals & action planning", style="Title.TLabel").pack(anchor="w")
        self._label(tab, "The planner records objectives and progress; it does not execute arbitrary OS actions.", style="Sub.TLabel", wraplength=820).pack(anchor="w", pady=(2, 8))
        form = ttk.Frame(tab); form.pack(fill="x")
        self.goal_title_var = tk.StringVar(); self.goal_criteria_var = tk.StringVar(); self.goal_priority_var = tk.IntVar(value=3)
        ttk.Label(form, text="Goal").grid(row=0, column=0, sticky="w")
        ttk.Entry(form, textvariable=self.goal_title_var, width=52).grid(row=0, column=1, sticky="ew", padx=6, pady=3)
        ttk.Label(form, text="Priority").grid(row=0, column=2, sticky="w")
        ttk.Spinbox(form, from_=1, to=5, textvariable=self.goal_priority_var, width=4).grid(row=0, column=3, padx=6)
        ttk.Label(form, text="Success criteria").grid(row=1, column=0, sticky="w")
        ttk.Entry(form, textvariable=self.goal_criteria_var, width=65).grid(row=1, column=1, columnspan=3, sticky="ew", padx=6, pady=3)
        ttk.Button(form, text="Create goal", command=self.create_goal).grid(row=0, column=4, rowspan=2, padx=6)
        form.columnconfigure(1, weight=1)
        body = ttk.Frame(tab); body.pack(fill="both", expand=True, pady=(10, 0))
        left = ttk.Frame(body); left.pack(side="left", fill="both", expand=True)
        self.goals_listbox = tk.Listbox(left, height=12, bg="#172531", fg="#e9f0f6", selectbackground="#285b66", relief="flat")
        self.goals_listbox.pack(fill="both", expand=True); self.goals_listbox.bind("<<ListboxSelect>>", self._show_goal_detail)
        right = ttk.Frame(body); right.pack(side="left", fill="both", expand=True, padx=(10, 0))
        self.goal_detail = tk.Text(right, height=10, wrap="word", bg="#172531", fg="#e9f0f6", relief="flat", padx=8, pady=8, state="disabled")
        self.goal_detail.pack(fill="both", expand=True)
        self.goal_note_var = tk.StringVar()
        ttk.Entry(right, textvariable=self.goal_note_var).pack(fill="x", pady=5)
        controls = ttk.Frame(right); controls.pack(fill="x")
        ttk.Button(controls, text="Add note", command=lambda: self.update_goal(None)).pack(side="left")
        ttk.Button(controls, text="Start", command=lambda: self.update_goal("in_progress")).pack(side="left", padx=3)
        ttk.Button(controls, text="Block", command=lambda: self.update_goal("blocked")).pack(side="left", padx=3)
        ttk.Button(controls, text="Complete", command=lambda: self.update_goal("completed")).pack(side="left", padx=3)
        ttk.Button(controls, text="Cancel", command=lambda: self.update_goal("cancelled")).pack(side="left", padx=3)

    def _build_predictions_tab(self):
        tab = ttk.Frame(self.agency_tabs, padding=12); self.agency_tabs.add(tab, text="Predictions")
        self._label(tab, "Prediction → observation → error proxy", style="Title.TLabel").pack(anchor="w")
        self._label(tab, "Outcomes use transparent word-overlap similarity. This is not calibrated probability or a scientific world model.", style="Sub.TLabel", wraplength=820).pack(anchor="w", pady=(2, 8))
        self.pred_context_var = tk.StringVar(); self.pred_expected_var = tk.StringVar(); self.pred_confidence_var = tk.DoubleVar(value=0.5)
        form = ttk.Frame(tab); form.pack(fill="x")
        ttk.Label(form, text="Context").grid(row=0, column=0, sticky="w")
        ttk.Entry(form, textvariable=self.pred_context_var).grid(row=0, column=1, sticky="ew", padx=6, pady=3)
        ttk.Label(form, text="Expected outcome").grid(row=1, column=0, sticky="w")
        ttk.Entry(form, textvariable=self.pred_expected_var).grid(row=1, column=1, sticky="ew", padx=6, pady=3)
        ttk.Label(form, text="Confidence (self-reported)").grid(row=2, column=0, sticky="w")
        ttk.Scale(form, from_=0.0, to=1.0, variable=self.pred_confidence_var, orient="horizontal").grid(row=2, column=1, sticky="ew", padx=6, pady=4)
        ttk.Button(form, text="Record prediction", command=self.create_prediction).grid(row=0, column=2, rowspan=3, padx=8)
        form.columnconfigure(1, weight=1)
        body = ttk.Frame(tab); body.pack(fill="both", expand=True, pady=(10, 0))
        self.pred_listbox = tk.Listbox(body, height=12, bg="#172531", fg="#e9f0f6", selectbackground="#285b66", relief="flat")
        self.pred_listbox.pack(side="left", fill="both", expand=True); self.pred_listbox.bind("<<ListboxSelect>>", self._show_prediction_detail)
        right = ttk.Frame(body); right.pack(side="left", fill="both", expand=True, padx=(10, 0))
        self.pred_detail = tk.Text(right, height=10, wrap="word", bg="#172531", fg="#e9f0f6", relief="flat", padx=8, pady=8, state="disabled")
        self.pred_detail.pack(fill="both", expand=True)
        self.pred_observed_var = tk.StringVar()
        ttk.Label(right, text="Observed outcome").pack(anchor="w", pady=(6, 0))
        ttk.Entry(right, textvariable=self.pred_observed_var).pack(fill="x", pady=4)
        ttk.Button(right, text="Evaluate selected prediction", command=self.evaluate_prediction).pack(anchor="w")

    def _build_files_tab(self):
        tab = ttk.Frame(self.agency_tabs, padding=12); self.agency_tabs.add(tab, text="Files")
        self._label(tab, "Explicit file permissions", style="Title.TLabel").pack(anchor="w")
        self._label(tab, "Choose each file yourself. Only supported text/code formats are read; there is no recursive crawling or background filesystem surveillance.", style="Sub.TLabel", wraplength=820).pack(anchor="w", pady=(2, 8))
        self.file_path_var = tk.StringVar()
        filebar = ttk.Frame(tab); filebar.pack(fill="x")
        ttk.Entry(filebar, textvariable=self.file_path_var).pack(side="left", fill="x", expand=True)
        ttk.Button(filebar, text="Browse…", command=self.choose_file).pack(side="left", padx=4)
        controls = ttk.Frame(tab); controls.pack(fill="x", pady=7)
        ttk.Button(controls, text="Grant access", command=self.grant_file).pack(side="left")
        ttk.Button(controls, text="Ingest this file", command=self.ingest_file).pack(side="left", padx=5)
        ttk.Button(controls, text="Revoke access", command=self.revoke_file).pack(side="left")
        self.files_listbox = tk.Listbox(tab, height=9, bg="#172531", fg="#e9f0f6", selectbackground="#285b66", relief="flat")
        self.files_listbox.pack(fill="both", expand=True, pady=(4, 6)); self.files_listbox.bind("<<ListboxSelect>>", self._select_granted_file)
        self.files_result = tk.StringVar(value="Supported extensions: .txt .md .rst .py .json .csv .log · max 1 MB per file by default")
        self._label(tab, "", textvariable=self.files_result, wraplength=820).pack(anchor="w")

    def _build_colony_tab(self):
        tab = ttk.Frame(self.agency_tabs, padding=12); self.agency_tabs.add(tab, text="Colony")
        self._label(tab, "Creator console · organism colony", style="Title.TLabel").pack(anchor="w")
        self._label(tab, "Separate local databases, generation metadata, optional knowledge inheritance, and authenticated encrypted local inbox messages. This is not a network transport.", style="Sub.TLabel", wraplength=820).pack(anchor="w", pady=(2, 8))
        create = ttk.Frame(tab); create.pack(fill="x")
        self.colony_name_var = tk.StringVar(value="New organism")
        self.colony_parent_var = tk.StringVar(value="No parent")
        self.colony_inherit_var = tk.BooleanVar(value=False)
        ttk.Label(create, text="Name").pack(side="left")
        ttk.Entry(create, textvariable=self.colony_name_var, width=20).pack(side="left", padx=5)
        ttk.Label(create, text="Parent").pack(side="left")
        self.colony_parent_combo = ttk.Combobox(create, textvariable=self.colony_parent_var, state="readonly", width=24)
        self.colony_parent_combo.pack(side="left", padx=5)
        ttk.Checkbutton(create, text="Inherit up to 500 memories", variable=self.colony_inherit_var).pack(side="left", padx=4)
        ttk.Button(create, text="Create", command=self.create_colony_organism).pack(side="left", padx=4)
        body = ttk.Frame(tab); body.pack(fill="both", expand=True, pady=(10, 0))
        left = ttk.Frame(body); left.pack(side="left", fill="both", expand=True)
        self.colony_listbox = tk.Listbox(left, height=11, bg="#172531", fg="#e9f0f6", selectbackground="#285b66", relief="flat")
        self.colony_listbox.pack(fill="both", expand=True); self.colony_listbox.bind("<<ListboxSelect>>", self._show_colony_inbox)
        right = ttk.Frame(body); right.pack(side="left", fill="both", expand=True, padx=(10, 0))
        self.colony_inbox = tk.Listbox(right, height=11, bg="#172531", fg="#e9f0f6", selectbackground="#285b66", relief="flat")
        self.colony_inbox.pack(fill="both", expand=True)
        self.colony_message_var = tk.StringVar()
        ttk.Entry(right, textvariable=self.colony_message_var).pack(fill="x", pady=5)
        mbar = ttk.Frame(right); mbar.pack(fill="x")
        ttk.Button(mbar, text="Send to selected", command=self.send_colony_message).pack(side="left")
        ttk.Button(mbar, text="Broadcast to all", command=self.broadcast_colony_message).pack(side="left", padx=5)
        ttk.Button(mbar, text="Mark inbox read", command=self.mark_colony_inbox_read).pack(side="left", padx=5)
        runtimes = ttk.Frame(tab); runtimes.pack(fill="x", pady=(10, 3))
        ttk.Label(runtimes, text="Child runtime lifecycle:").pack(side="left", padx=(0, 6))
        ttk.Button(runtimes, text="Start selected", command=self.start_colony_selected).pack(side="left", padx=2)
        ttk.Button(runtimes, text="Pause / resume", command=self.toggle_colony_runtime_pause).pack(side="left", padx=2)
        ttk.Button(runtimes, text="Stop selected", command=self.stop_colony_selected).pack(side="left", padx=2)
        ttk.Button(runtimes, text="Start all children", command=self.start_all_colony_runtimes).pack(side="left", padx=2)
        ttk.Button(runtimes, text="Stop all children", command=self.stop_all_colony_runtimes).pack(side="left", padx=2)
        self.colony_status_var = tk.StringVar(value="Child organisms run as separate supervised Python processes. Inbox messages are never executed as commands.")
        self._label(tab, "", textvariable=self.colony_status_var, wraplength=820).pack(anchor="w", pady=(7, 0))
        self._colony_list_rows = []; self._colony_parent_map = {}

    def _build_dynamics_tab(self):
        tab = ttk.Frame(self.agency_tabs, padding=12); self.agency_tabs.add(tab, text="Neural core")
        self._label(tab, "Adaptive recurrent substrate & semantic memory", style="Title.TLabel").pack(anchor="w")
        self._label(tab, "The 24-unit recurrent core has local online plasticity. Optional semantic embeddings use only your local Ollama server at 127.0.0.1:11434.", style="Sub.TLabel", wraplength=820).pack(anchor="w", pady=(2, 8))
        self.dynamics_box = tk.Text(tab, height=17, wrap="word", bg="#172531", fg="#e9f0f6", relief="flat", padx=10, pady=10, state="disabled")
        self.dynamics_box.pack(fill="both", expand=True)
        bar = ttk.Frame(tab); bar.pack(fill="x", pady=7)
        ttk.Button(bar, text="Refresh neural metrics", command=self.refresh_dynamics).pack(side="left")
        ttk.Button(bar, text="Index next 100 memories semantically", command=self.index_semantic_memories).pack(side="left", padx=6)
        self.semantic_status_var = tk.StringVar(value="")
        self._label(tab, "", textvariable=self.semantic_status_var, wraplength=820).pack(anchor="w")
        self._label(tab, "To enable semantic retrieval, pull a local embedding model (for example `ollama pull nomic-embed-text`), set ALIFE_OLLAMA_EMBED_MODEL=nomic-embed-text before launch, then index memories here. Without it, the organism stays offline-capable with lexical and recurrent retrieval.", style="Sub.TLabel", wraplength=820).pack(anchor="w", pady=(7, 0))

    def _set_text(self, widget, value):
        widget.configure(state="normal")
        widget.delete("1.0", "end")
        widget.insert("1.0", value)
        widget.configure(state="disabled")

    def refresh_goals(self):
        if not hasattr(self, "goals_listbox") or not self.goals_listbox.winfo_exists(): return
        self.goal_rows = sorted(self.goal_manager.list(), key=lambda g: (g.get("status") not in ("pending", "in_progress"), -int(g.get("priority", 3)), g.get("created_at", 0)))
        self.goals_listbox.delete(0, "end")
        for goal in self.goal_rows:
            self.goals_listbox.insert("end", f"P{goal['priority']} · {goal['status'].upper()} · {goal['title'][:90]}")
        if self.goal_rows:
            self.goals_listbox.selection_set(0); self._show_goal_detail()
        else:
            self._set_text(self.goal_detail, "No goals yet. Create a goal with explicit success criteria.")

    def _selected_goal(self):
        selection = self.goals_listbox.curselection() if hasattr(self, "goals_listbox") else ()
        return self.goal_rows[selection[0]] if selection and selection[0] < len(getattr(self, "goal_rows", [])) else None

    def _show_goal_detail(self, _event=None):
        goal = self._selected_goal()
        if not goal: return
        lines = [f"ID: {goal['id']}", f"Title: {goal['title']}", f"Status: {goal['status']}", f"Priority: {goal['priority']}/5", f"Success criteria: {goal.get('success_criteria') or '(not specified)'}", f"Created: {time.strftime('%Y-%m-%d %H:%M:%S', time.localtime(goal['created_at']))}", "", "Progress notes:"]
        lines.extend(f"- {n['text']}" for n in goal.get("notes", [])[-20:])
        self._set_text(self.goal_detail, "\n".join(lines))

    def create_goal(self):
        try:
            goal = self.goal_manager.create(self.goal_title_var.get(), self.goal_criteria_var.get(), self.goal_priority_var.get())
            self.store.db.commit(); self.life.note_event("goal created")
            self.goal_title_var.set(""); self.goal_criteria_var.set("")
            self.refresh_goals(); self.refresh_all()
        except Exception as exc:
            messagebox.showerror("Could not create goal", str(exc), parent=self.panel)

    def update_goal(self, status):
        goal = self._selected_goal()
        if not goal:
            messagebox.showinfo("Select a goal", "Select a goal first.", parent=self.panel); return
        note = self.goal_note_var.get().strip() or None
        try:
            self.goal_manager.update(goal["id"], status=status, note=note)
            self.goal_note_var.set(""); self.store.db.commit(); self.life.note_event("goal updated")
            self.refresh_goals(); self.refresh_all()
        except Exception as exc:
            messagebox.showerror("Could not update goal", str(exc), parent=self.panel)

    def refresh_predictions(self):
        if not hasattr(self, "pred_listbox") or not self.pred_listbox.winfo_exists(): return
        self.pred_rows = self.prediction_engine.list(100)
        self.pred_listbox.delete(0, "end")
        for item in self.pred_rows:
            self.pred_listbox.insert("end", f"{item['status'].upper()} · {item['confidence']:.0%} · {item['context'][:75]}")
        if self.pred_rows:
            self.pred_listbox.selection_set(0); self._show_prediction_detail()
        else:
            self._set_text(self.pred_detail, "No predictions recorded yet.")

    def _selected_prediction(self):
        selection = self.pred_listbox.curselection() if hasattr(self, "pred_listbox") else ()
        return self.pred_rows[selection[0]] if selection and selection[0] < len(getattr(self, "pred_rows", [])) else None

    def _show_prediction_detail(self, _event=None):
        item = self._selected_prediction()
        if not item: return
        lines = [f"ID: {item['id']}", f"Status: {item['status']}", f"Context: {item['context']}", f"Expected: {item['expected']}", f"Self-reported confidence: {item['confidence']:.3f}"]
        if item.get("observed") is not None:
            lines.extend([f"Observed: {item['observed']}", f"Word-overlap similarity proxy: {item.get('similarity_proxy')}", f"Prediction-error proxy: {item.get('prediction_error_proxy')}"])
        self._set_text(self.pred_detail, "\n".join(lines))

    def create_prediction(self):
        try:
            item = self.prediction_engine.predict(self.pred_context_var.get(), self.pred_expected_var.get(), self.pred_confidence_var.get())
            self.store.db.commit(); self.life.note_event("prediction recorded")
            self.refresh_predictions(); self.refresh_all()
            self._set_text(self.pred_detail, f"Prediction recorded.\nID: {item['id']}\nRecord the actual outcome later to evaluate the proxy.")
        except Exception as exc:
            messagebox.showerror("Could not record prediction", str(exc), parent=self.panel)

    def evaluate_prediction(self):
        item = self._selected_prediction(); observed = self.pred_observed_var.get().strip()
        if not item:
            messagebox.showinfo("Select a prediction", "Select a pending prediction first.", parent=self.panel); return
        if not observed:
            messagebox.showinfo("Observed outcome required", "Enter what actually happened.", parent=self.panel); return
        try:
            result = self.prediction_engine.observe(item["id"], observed)
            self.pred_observed_var.set(""); self.store.db.commit(); self.life.note_event("prediction evaluated")
            self.refresh_predictions(); self.refresh_all()
            messagebox.showinfo("Prediction evaluated", f"Word-overlap similarity proxy: {result['similarity_proxy']:.3f}\nError proxy: {result['prediction_error_proxy']:.3f}\n\nThis is not calibrated probability.", parent=self.panel)
        except Exception as exc:
            messagebox.showerror("Could not evaluate prediction", str(exc), parent=self.panel)

    def choose_file(self):
        path = filedialog.askopenfilename(parent=self.panel, title="Choose a text or code file", filetypes=[("Supported text/code", "*.txt *.md *.rst *.py *.json *.csv *.log"), ("All files", "*.*")])
        if path: self.file_path_var.set(path)

    def _current_file_path(self):
        value = self.file_path_var.get().strip()
        if value: return value
        if hasattr(self, "files_listbox"):
            selection = self.files_listbox.curselection()
            grants = self.store.get_meta("file_grants", []) or []
            if selection and selection[0] < len(grants): return grants[selection[0]].get("path", "")
        return ""

    def refresh_files(self):
        if not hasattr(self, "files_listbox") or not self.files_listbox.winfo_exists(): return
        grants = self.store.get_meta("file_grants", []) or []
        self.file_grant_rows = grants
        self.files_listbox.delete(0, "end")
        for grant in grants:
            mark = "GRANTED" if grant.get("granted") else "REVOKED"
            self.files_listbox.insert("end", f"{mark} · {grant.get('path', '')}")

    def _select_granted_file(self, _event=None):
        selection = self.files_listbox.curselection()
        if selection and selection[0] < len(self.file_grant_rows): self.file_path_var.set(self.file_grant_rows[selection[0]].get("path", ""))

    def grant_file(self):
        path = self._current_file_path()
        if not path:
            messagebox.showinfo("Choose a file", "Choose a single text or code file first.", parent=self.panel); return
        try:
            grant = self.permissioned_files.grant(path); self.store.db.commit()
            self.files_result.set(f"Explicit access granted to {grant['path']}. This does not ingest it yet.")
            self.refresh_files(); self.refresh_all()
        except Exception as exc:
            messagebox.showerror("Could not grant file access", str(exc), parent=self.panel)

    def ingest_file(self):
        path = self._current_file_path()
        if not path:
            messagebox.showinfo("Choose a file", "Choose a single file first.", parent=self.panel); return
        try:
            result = self.permissioned_files.ingest(path); self.store.db.commit(); self.life.note_event("permissioned file ingested")
            self.files_result.set(f"Ingested {result.get('statements', 0)} statement(s) from this explicitly granted file. New memories: {result.get('new_knowledge', 0)}.")
            self.refresh_all()
        except Exception as exc:
            messagebox.showerror("Could not ingest file", str(exc), parent=self.panel)

    def revoke_file(self):
        path = self._current_file_path()
        if not path:
            messagebox.showinfo("Choose a file", "Choose a granted file first.", parent=self.panel); return
        try:
            self.permissioned_files.revoke(path); self.store.db.commit()
            self.files_result.set(f"Access revoked for {path}. Previously learned memories remain until you manage memory separately.")
            self.refresh_files(); self.refresh_all()
        except Exception as exc:
            messagebox.showerror("Could not revoke file access", str(exc), parent=self.panel)

    def refresh_colony(self):
        if not hasattr(self, "colony_listbox") or not self.colony_listbox.winfo_exists(): return
        try:
            rows = self.runtime_supervisor.poll()
        except Exception:
            rows = self.colony.list()
        self._colony_list_rows = rows
        current_id = None
        old_selection = self.colony_listbox.curselection()
        if old_selection and old_selection[0] < len(rows): current_id = rows[old_selection[0]]["id"]
        self.colony_listbox.delete(0, "end")
        self._colony_parent_map = {"No parent": None}
        labels = ["No parent"]
        for row in rows:
            label = f"{row['name']} · gen {row['generation']} · {row['id'][:8]}"
            labels.append(label); self._colony_parent_map[label] = row["id"]
            if row.get("primary"):
                runtime_label = "PRIMARY · embedded"
            else:
                runtime_label = f"{str(row.get('runtime_state', 'stopped')).upper()} · pid {row.get('pid') or '-'} · inbox {row.get('pending_inbox', 0)}"
            self.colony_listbox.insert("end", f"{row['name']} · gen {row['generation']} · {row['id'][:8]} · {runtime_label}")
        self.colony_parent_combo["values"] = labels
        if self.colony_parent_var.get() not in self._colony_parent_map: self.colony_parent_var.set(labels[0])
        if rows:
            idx = next((i for i, row in enumerate(rows) if row["id"] == current_id), 0)
            self.colony_listbox.selection_set(idx); self._show_colony_inbox()
        else:
            self.colony_inbox.delete(0, "end")
        security = self.colony.security_status()
        statuses = {r.get("runtime_state") for r in rows if not r.get("primary")}
        running = sum(1 for r in rows if not r.get("primary") and r.get("alive"))
        if security.get("enabled"):
            self.colony_status_var.set(f"Child runtimes: {running} process(es) alive. States: {', '.join(sorted(statuses)) or 'no children'}. Inbox uses local authenticated encryption; messages are never executed, and no network transport is implemented.")
        else:
            self.colony_status_var.set(f"Runtime monitoring active. Colony message encryption unavailable: {security.get('error', 'unknown error')}")

    def _poll_colony_runtimes(self):
        try:
            self.runtime_supervisor.poll()
            if self.panel and self.panel.winfo_exists() and hasattr(self, "colony_listbox"):
                self.refresh_colony()
        except Exception as exc:
            logging.getLogger("alife.desktop").warning("Colony runtime supervision error: %s", exc)
        if self.root.winfo_exists():
            self.root.after(2000, self._poll_colony_runtimes)

    def start_colony_selected(self):
        row = self._selected_colony_row()
        if not row: messagebox.showinfo("Select organism", "Select a child organism first.", parent=self.panel); return
        try:
            self.runtime_supervisor.start_organism(row["id"])
            self.refresh_colony()
        except Exception as exc: messagebox.showerror("Runtime start failed", str(exc), parent=self.panel)

    def toggle_colony_runtime_pause(self):
        row = self._selected_colony_row()
        if not row: messagebox.showinfo("Select organism", "Select a child organism first.", parent=self.panel); return
        if row.get("primary"):
            messagebox.showinfo("Primary organism", "Use the main Pause / resume control for the primary organism.", parent=self.panel); return
        try:
            if row.get("desired_state") == "paused": self.runtime_supervisor.resume_organism(row["id"])
            elif row.get("desired_state") == "running": self.runtime_supervisor.pause_organism(row["id"])
            else: self.runtime_supervisor.start_organism(row["id"])
            self.refresh_colony()
        except Exception as exc: messagebox.showerror("Runtime state change failed", str(exc), parent=self.panel)

    def stop_colony_selected(self):
        row = self._selected_colony_row()
        if not row: messagebox.showinfo("Select organism", "Select a child organism first.", parent=self.panel); return
        try:
            self.runtime_supervisor.stop_organism(row["id"])
            self.refresh_colony()
        except Exception as exc: messagebox.showerror("Runtime stop failed", str(exc), parent=self.panel)

    def start_all_colony_runtimes(self):
        try:
            results = self.runtime_supervisor.start_all()
            self.refresh_colony()
            messagebox.showinfo("Child runtimes started", f"Started or requested {len(results)} child organism runtime(s).", parent=self.panel)
        except Exception as exc: messagebox.showerror("Could not start colony", str(exc), parent=self.panel)

    def stop_all_colony_runtimes(self):
        try:
            results = self.runtime_supervisor.stop_all()
            self.refresh_colony()
            messagebox.showinfo("Child runtimes stopped", f"Stopped {len(results)} child organism runtime(s).", parent=self.panel)
        except Exception as exc: messagebox.showerror("Could not stop colony", str(exc), parent=self.panel)

    def _selected_colony_row(self):
        selection = self.colony_listbox.curselection() if hasattr(self, "colony_listbox") else ()
        return self._colony_list_rows[selection[0]] if selection and selection[0] < len(getattr(self, "_colony_list_rows", [])) else None

    def _show_colony_inbox(self, _event=None):
        row = self._selected_colony_row()
        if not row: return
        try:
            messages = self.colony.read_inbox(row["id"])
            self.colony_inbox.delete(0, "end")
            if not messages: self.colony_inbox.insert("end", "(Inbox empty)")
            for msg in messages:
                at = time.strftime("%m-%d %H:%M", time.localtime(msg.get("at") or 0))
                prefix = "INVALID" if msg.get("invalid") else ("READ" if msg.get("read") else "NEW")
                self.colony_inbox.insert("end", f"{prefix} · {at} · {msg.get('sender', '?')}: {str(msg.get('message', ''))[:130]}")
        except Exception as exc:
            self.colony_inbox.delete(0, "end"); self.colony_inbox.insert("end", f"Inbox error: {str(exc)[:120]}")

    def mark_colony_inbox_read(self):
        row = self._selected_colony_row()
        if not row: return
        try:
            self.colony.read_inbox(row["id"], mark_read=True)
            self._show_colony_inbox()
        except Exception as exc:
            messagebox.showerror("Could not mark inbox read", str(exc), parent=self.panel)

    def create_colony_organism(self):
        name = self.colony_name_var.get().strip()
        parent_id = self._colony_parent_map.get(self.colony_parent_var.get())
        try:
            row = self.colony.create(name, parent_id=parent_id, inherit_knowledge=bool(self.colony_inherit_var.get()))
            self.colony_name_var.set("New organism"); self.refresh_colony(); self.refresh_all()
            for idx, existing in enumerate(self._colony_list_rows):
                if existing["id"] == row["id"]:
                    self.colony_listbox.selection_clear(0, "end"); self.colony_listbox.selection_set(idx); self.colony_listbox.see(idx); self._show_colony_inbox(); break
            messagebox.showinfo("Organism created", f"{row['name']}\nGeneration: {row['generation']}\nIndependent database created. Use Start selected in Colony to launch its supervised background runtime.", parent=self.panel)
        except Exception as exc:
            messagebox.showerror("Could not create organism", str(exc), parent=self.panel)

    def send_colony_message(self):
        row = self._selected_colony_row(); message = self.colony_message_var.get().strip()
        if not row or not message:
            messagebox.showinfo("Select organism and message", "Select a colony member and enter a message.", parent=self.panel); return
        try:
            self.colony.deliver(row["id"], message, sender=self.store.get_meta("identity", {}).get("name", "creator"))
            self.colony_message_var.set(""); self._show_colony_inbox(); self.refresh_all()
        except Exception as exc:
            messagebox.showerror("Could not send message", str(exc), parent=self.panel)

    def broadcast_colony_message(self):
        message = self.colony_message_var.get().strip()
        if not message:
            messagebox.showinfo("Message required", "Enter a message to broadcast.", parent=self.panel); return
        try:
            sent = self.colony.broadcast(message, sender=self.store.get_meta("identity", {}).get("name", "creator"))
            self.colony_message_var.set(""); self.refresh_colony(); self.refresh_all()
            messagebox.showinfo("Broadcast queued", f"Encrypted message envelopes written for {len(sent)} organism(s).", parent=self.panel)
        except Exception as exc:
            messagebox.showerror("Broadcast failed", str(exc), parent=self.panel)

    def refresh_dynamics(self):
        if not hasattr(self, "dynamics_box") or not self.dynamics_box.winfo_exists(): return
        report = {"adaptive_recurrent_substrate": self.brain.dynamics.report(), "semantic_memory": self.brain.semantic.status(), "runtime_resource_sample": self.runtime_guard.sample()}
        self._set_text(self.dynamics_box, json.dumps(report, ensure_ascii=False, indent=2))
        semantic = report["semantic_memory"]
        if semantic["enabled"]:
            self.semantic_status_var.set(f"Embedding model: {semantic['model']} · cached items: {semantic['cached_items']} · local endpoint only.")
        else:
            self.semantic_status_var.set("Semantic embeddings disabled. Set ALIFE_OLLAMA_EMBED_MODEL before launch to enable optional local vector retrieval.")

    def index_semantic_memories(self):
        try:
            if not self.brain.semantic.enabled:
                messagebox.showinfo("Embeddings disabled", "Set ALIFE_OLLAMA_EMBED_MODEL before launching, and make sure Ollama is running locally.", parent=self.panel); return
            rows = self.brain.semantic.pending_rows(self.store.knowledge_rows(limit=5000), limit=100)
            if not rows:
                self.refresh_dynamics(); messagebox.showinfo("Index is current", "No unindexed memories were found in the current knowledge window.", parent=self.panel); return
            result = self.brain.semantic.index_rows(rows, limit=len(rows))
            self.store.db.commit(); self.life.note_event("semantic indexing")
            self.refresh_dynamics(); self.refresh_all()
            self.semantic_status_var.set(f"Indexed {result['new_embeddings']} new memories with {result['model']}. Cached vectors: {result['cached_embeddings']}. Click again to index another batch.")
        except Exception as exc:
            messagebox.showerror("Semantic indexing failed", str(exc), parent=self.panel)

    def feed_life(self):
        text = self.life_text.get("1.0", "end").strip()
        if not text: return
        self.state, self.status_line = "learning", "Learning from new information"
        self._draw(); self.root.update_idletasks()
        try:
            result = self.brain.learn(text, "pet-food")
            self.life.note_event("owner supplied information")
            self.learn_result.set(f"Learned {result['statements']} statement(s); +{result['new_memory_neurons']} memory neuron(s), +{result['new_concept_neurons']} concept neuron(s), {result['edge_updates']} relationship updates.")
            self.refresh_all()
        except Exception as exc:
            messagebox.showerror("Could not learn", str(exc), parent=self.panel)
        finally:
            self.state = "idle"; self._refresh_runtime()

    def learn_knowledge(self):
        text = self.knowledge_text.get("1.0", "end").strip()
        try:
            result = self.brain.learn(text, self.source_var.get().strip() or "owner")
            self.life.note_event("knowledge ingestion")
            self.knowledge_result.set(json.dumps(result, indent=2))
            self.state, self.status_line = "learning", "New knowledge integrated"
            self.refresh_all()
        except Exception as exc:
            messagebox.showerror("Could not ingest", str(exc), parent=self.panel)

    def ask(self):
        question = self.question.get("1.0", "end").strip()
        try:
            result = self.brain.ask(question, bool(self.use_llm.get()))
            self.life.note_event("question answered")
            self.answer_ids = [e["id"] for e in result.get("evidence", [])]
            evidence_text = "\n\nEvidence:\n" + "\n".join(f"[{e['id']}] {e['text']}  (source: {e['source']}, match: {e['score']})" for e in result.get("evidence", [])) if result.get("evidence") else "\n\nNo evidence matched. Feed relevant information first."
            self._set_text(self.answer, result["answer"] + evidence_text)
            self.answer_note.set("Method: " + result.get("method", "unknown") + (" · " + result.get("model_note", "") if result.get("model_note") else ""))
            self.state, self.status_line = "curious", "Connected memories"
            self.refresh_all()
        except Exception as exc:
            messagebox.showerror("Could not answer", str(exc), parent=self.panel)

    def feedback(self, helpful: bool):
        if not self.answer_ids:
            messagebox.showinfo("No evidence", "Ask a question that retrieves memories first.", parent=self.panel); return
        try:
            changed = self.brain.feedback(self.answer_ids, helpful)
            self.life.note_event("evidence feedback")
            self.answer_note.set(f"Feedback saved for {changed} evidence item(s). Facts were not rewritten.")
            self.refresh_all()
        except Exception as exc:
            messagebox.showerror("Could not save feedback", str(exc), parent=self.panel)

    def rename(self):
        name = self.name_var.get().strip()
        if not name or len(name) > 80 or any(ord(c) < 32 for c in name):
            messagebox.showerror("Invalid name", "Use 1–80 printable characters.", parent=self.panel); return
        identity = self.store.get_meta("identity")
        identity["name"] = name
        self.store.set_meta("identity", identity)
        self.store.log("rename", {"name": name}); self.store.db.commit()
        self.refresh_all(); self._draw()

    def toggle_pause(self):
        paused = not bool(self.store.get_meta("paused", False))
        self.store.set_meta("paused", paused); self.store.log("pause" if paused else "resume", {}); self.store.db.commit()
        self.status_line = "Runtime paused" if paused else "Back and ready"
        self.state = "paused" if paused else "idle"
        if self.panel and self.panel.winfo_exists():
            self.refresh_all()
        self._draw()

    def refresh_all(self):
        self._update_dashboard_stats()
        if hasattr(self, "neurons_box"):
            rows = self.store.neurons_rows(limit=100)
            text = "\n".join(f"#{r['id']} · {r['kind'].upper()} · strength {r['strength']:.2f} · current activation {r['activation']:.2f} · activations {r['activation_count']}\n  {r['label']}" for r in rows) or "No neurons yet. Feed the organism to start growing its network."
            self._set_text(self.neurons_box, text)
        if hasattr(self, "activity_box"):
            rows = self.store.log_rows(limit=50)
            text = "\n".join(f"{r['id']} · {r['event']} · {json.dumps(r['detail'], ensure_ascii=False)[:200]}" for r in rows) or "No activity recorded yet."
            self._set_text(self.activity_box, text)
        self._refresh_mind()
        for refresh_name in ("refresh_goals", "refresh_predictions", "refresh_files", "refresh_colony", "refresh_dynamics"):
            refresh_method = getattr(self, refresh_name, None)
            if callable(refresh_method):
                try: refresh_method()
                except Exception as exc: self.store.log("panel_refresh_error", {"panel": refresh_name, "error": str(exc)[:160]})

    def _refresh_mind(self):
        if not hasattr(self, "self_model_box") or not self.self_model_box.winfo_exists():
            return
        state = self.life.state()
        counts = self.store.db.execute("SELECT relation,COUNT(*) n FROM edges GROUP BY relation ORDER BY relation").fetchall()
        edge_counts = {r["relation"]: r["n"] for r in counts}
        self.mind_state_var.set(
            f"Energy budget: {state['energy']:.1f}/100  ·  Curiosity priority: {state['curiosity']:.1f}/100  ·  Data-quality stability: {state['stability']:.1f}/100\n"
            f"Ticks: {state['cycle_count']}  ·  Reflection passes: {state['reflection_count']}  ·  Associations: {edge_counts.get('associates', 0)}  ·  Potential conflicts to review: {edge_counts.get('potential_conflict', 0)}\n"
            f"Last cycle: {state.get('last_cycle_summary', 'None yet')}\n"
            f"Pending goals / unanswered questions: {len(self.store.get_meta('pending_goals', []) or [])} (re-ask after adding evidence to resolve).\n"
            "Note: 'energy', 'curiosity', and 'stability' are bounded controller variables, not felt sensations."
        )
        report = self.brain.self_model()
        report["relationship_types"] = edge_counts
        report["last_cycle_summary"] = state.get("last_cycle_summary")
        self._set_text(self.self_model_box, json.dumps(report, ensure_ascii=False, indent=2))

    def run_reflection(self):
        try:
            state = self.life.tick(force_reflection=True)
            if state.get("paused"):
                messagebox.showinfo("Organism paused", "Resume the organism before running a reflection cycle.", parent=self.panel)
            else:
                self.status_line = "Reviewing memory associations"
                self.state = "curious"
                self.refresh_all()
        except Exception as exc:
            messagebox.showerror("Reflection cycle failed", str(exc), parent=self.panel)

    def _life_cycle(self):
        try:
            self._last_resource_sample = self.runtime_guard.sample()
            if self.store.get_meta("paused", False):
                result = self.life.tick()
            elif not self._last_resource_sample.get("cooldown_active", False):
                result = self.life.tick()
            else:
                result = {"cycle": None, "paused": False}
                self.status_line = "Background cognition resting under system load"
            if result.get("cycle"):
                cycle = result["cycle"]
                self.status_line = ("Connected memories" if cycle.get("new_associations", 0) else "Reviewed recent memories")
                if not self.store.get_meta("paused", False): self.state = "curious"
            if time.time() - self._last_backup_at >= 600:
                try:
                    snap = self.runtime_guard.snapshot_database(keep=3)
                    self.store.log("database_snapshot_created", {"bytes": snap["bytes"], "retained": snap["retained"]})
                    self.store.db.commit(); self._last_backup_at = time.time()
                except Exception as backup_error:
                    logging.getLogger("alife.desktop").exception("Periodic database snapshot failed: %s", backup_error)
            if self.panel and self.panel.winfo_exists():
                self._refresh_mind(); self._update_dashboard_stats()
                if hasattr(self, "dynamics_box") and time.time() - getattr(self, "_last_dynamics_refresh", 0) > 45:
                    self.refresh_dynamics(); self._last_dynamics_refresh = time.time()
        except Exception as exc:
            self.status_line = f"Mind cycle issue: {str(exc)[:18]}"
            logging.getLogger("alife.desktop").exception("Background life cycle failed")
            try:
                self.store.log("life_cycle_error", {"error": str(exc)[:240]}); self.store.db.commit()
            except Exception: pass
        self._draw()
        self.root.after(15000, self._life_cycle)

    def _update_dashboard_stats(self):
        if not self.panel or not self.panel.winfo_exists() or not hasattr(self, "stats_var"):
            return
        stats = self.store.status()
        ident = stats["identity"]
        use = stats["resource_usage"]
        paused = "PAUSED" if stats["paused"] else "RUNNING"
        self.stats_var.set(f"{paused}  ·  ID {ident['id'][:8]}…  ·  generation {ident['generation']}  ·  {stats['neurons']['total']} neurons  ·  {stats['relationships']} relationships  ·  {stats['knowledge_items']} memories")
        if hasattr(self, "life_stats"):
            self.life_stats.set(f"Today: {use['chars_ingested']:,} characters · {use['work_units']:,} work units · {use['queries']} questions\nDatabase: {stats['database_bytes']:,} bytes · Activity entries: {stats['activity_events']}")
        if hasattr(self, "life_stats"):
            paused_now = stats["paused"]
            # Keep the label state truthful even when the overlay is animating.
            if paused_now:
                self.state, self.status_line = "paused", "Runtime paused"

    def close(self):
        try:
            self.store.set_meta("pet_geometry", {"x": self.root.winfo_x(), "y": self.root.winfo_y()})
            self.store.log("desktop_pet_closed", {})
            self.store.db.commit()
            try:
                snapshot = self.runtime_guard.snapshot_database(keep=3)
                logging.getLogger("alife.desktop").info("Final database snapshot created: %s", snapshot.get("path"))
            except Exception:
                logging.getLogger("alife.desktop").exception("Final database snapshot failed")
        except Exception:
            logging.getLogger("alife.desktop").exception("Shutdown persistence failed")
        finally:
            try: self.runtime_supervisor.close()
            except Exception: logging.getLogger("alife.desktop").exception("Colony supervisor shutdown failed")
            try: self.store.close()
            except Exception: logging.getLogger("alife.desktop").exception("Store close failed")
            try: self.root.destroy()
            except tk.TclError: pass

    def run(self):
        self.root.mainloop()


def _configure_runtime_logging():
    DATA_DIR.mkdir(parents=True, exist_ok=True)
    log_path = DATA_DIR / "runtime.log"
    handler = RotatingFileHandler(log_path, maxBytes=2_000_000, backupCount=3, encoding="utf-8")
    logging.basicConfig(level=logging.INFO, handlers=[handler], format="%(asctime)s %(levelname)s %(name)s %(message)s")
    logging.getLogger("alife.desktop").info("Runtime starting; platform=%s", platform.platform())
    crash_handle = open(DATA_DIR / "fatal_tracebacks.log", "a", encoding="utf-8")
    try: faulthandler.enable(crash_handle, all_threads=True)
    except Exception: pass
    original_hook = sys.excepthook
    def log_uncaught(exc_type, exc_value, traceback):
        logging.getLogger("alife.desktop").critical("Uncaught main-thread exception", exc_info=(exc_type, exc_value, traceback))
        original_hook(exc_type, exc_value, traceback)
    sys.excepthook = log_uncaught
    return crash_handle


def main():
    crash_handle = _configure_runtime_logging()
    store = None
    try:
        store = OrganismStore(str(DATA_DIR))
        brain = Brain(store, ResourceLimits())
        print("Artificial Life desktop pet starting...")
        print(f"Organism data: {DATA_DIR}")
        print("Native floating pet; no localhost dashboard is started.")
        app = DesktopPet(store, brain)
        app.run()
    except Exception:
        logging.getLogger("alife.desktop").exception("Fatal application start/run error")
        if store is not None:
            try: store.close()
            except Exception: pass
        raise
    finally:
        try:
            faulthandler.disable()
            crash_handle.close()
        except Exception: pass

if __name__ == "__main__":
    main()
