"""Best-effort resource monitoring and local database snapshots for the desktop runtime."""
from __future__ import annotations

import os
import time
from pathlib import Path


class RuntimeGuard:
    """Observe process resources and back off background cognition when over limits.

    These are application-level soft limits, not OS-enforced quotas or a sandbox.
    psutil is optional; without it, monitoring returns an explicit unavailable status.
    """
    def __init__(self, store, home):
        self.store = store
        self.home = Path(home).expanduser().resolve()
        try: rss_limit = int(os.environ.get("ALIFE_MAX_RSS_MB", "1024"))
        except (TypeError, ValueError): rss_limit = 1024
        try: cpu_limit = float(os.environ.get("ALIFE_MAX_CPU_PERCENT", "85"))
        except (TypeError, ValueError): cpu_limit = 85.0
        self.max_rss_mb = max(256, min(8192, rss_limit))
        self.max_cpu_percent = max(10.0, min(400.0, cpu_limit))
        self.cooldown_seconds = 60
        self._cooldown_until = 0.0
        self._process = None
        self._last_report = 0.0
        try:
            import psutil
            self._psutil = psutil
            self._process = psutil.Process(os.getpid())
            self._process.cpu_percent(None)
        except Exception:
            self._psutil = None

    def sample(self) -> dict:
        if self._psutil is None or self._process is None:
            return {"available": False, "reason": "psutil not installed", "soft_limits_enforced": False}
        try:
            rss_mb = self._process.memory_info().rss / (1024 * 1024)
            cpu_percent = float(self._process.cpu_percent(None))
            over_memory = rss_mb > self.max_rss_mb
            over_cpu = cpu_percent > self.max_cpu_percent
            if over_memory or over_cpu:
                self._cooldown_until = max(self._cooldown_until, time.time() + self.cooldown_seconds)
                if time.time() - self._last_report > 30:
                    with self.store.lock, self.store.db:
                        self.store.log("runtime_soft_limit_exceeded", {"rss_mb": round(rss_mb, 1), "cpu_percent": round(cpu_percent, 1), "max_rss_mb": self.max_rss_mb, "max_cpu_percent": self.max_cpu_percent})
                    self._last_report = time.time()
            return {"available": True, "rss_mb": round(rss_mb, 1), "cpu_percent": round(cpu_percent, 1),
                    "max_rss_mb": self.max_rss_mb, "max_cpu_percent": self.max_cpu_percent,
                    "over_soft_limit": bool(over_memory or over_cpu), "cooldown_active": time.time() < self._cooldown_until,
                    "soft_limits_enforced": False}
        except Exception as exc:
            return {"available": False, "reason": str(exc)[:160], "soft_limits_enforced": False}

    def background_allowed(self) -> bool:
        metrics = self.sample()
        return not bool(metrics.get("cooldown_active", False))

    def snapshot_database(self, keep: int = 3) -> dict:
        """Create a consistent SQLite backup and retain only the newest snapshots."""
        backup_dir = self.home / "backups"
        backup_dir.mkdir(parents=True, exist_ok=True)
        now = time.time()
        timestamp = time.strftime("%Y%m%d_%H%M%S", time.localtime(now))
        target = backup_dir / f"organism_{timestamp}_{time.time_ns() % 1_000_000:06d}.sqlite3"
        import sqlite3
        try:
            with self.store.lock:
                target_db = sqlite3.connect(target)
                try:
                    self.store.db.backup(target_db)
                    check = target_db.execute("PRAGMA quick_check").fetchone()
                    if not check or check[0] != "ok":
                        raise RuntimeError(f"backup integrity check failed: {check[0] if check else 'no result'}")
                    target_db.commit()
                finally:
                    target_db.close()
        except Exception:
            try: target.unlink()
            except OSError: pass
            raise
        try:
            if os.name != "nt": os.chmod(target, 0o600)
        except OSError:
            pass
        snapshots = sorted(backup_dir.glob("organism_*.sqlite3"), key=lambda path: path.stat().st_mtime, reverse=True)
        for old in snapshots[max(1, min(int(keep), 10)):]:
            try: old.unlink()
            except OSError: pass
        return {"path": str(target), "bytes": target.stat().st_size, "retained": min(len(snapshots), max(1, min(int(keep), 10)))}
