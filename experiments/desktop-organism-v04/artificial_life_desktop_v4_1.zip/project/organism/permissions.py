"""Explicit opt-in local file ingestion. No recursive crawling or hidden monitoring."""
from pathlib import Path

class PermissionedFiles:
    def __init__(self, brain, store, max_bytes=1_000_000): self.brain=brain; self.store=store; self.max_bytes=max(1024,int(max_bytes))
    def grant(self, path):
        p=Path(path).expanduser().resolve(strict=True)
        if not p.is_file(): raise ValueError('permission can only be granted to a regular file')
        grants=self.store.get_meta('file_grants',[])
        item={'path':str(p),'granted':True}
        if not any(x['path']==item['path'] for x in grants): grants.append(item)
        self.store.set_meta('file_grants',grants); self.store.log('file_permission_granted',{'path':str(p)}); return item
    def revoke(self, path):
        p=str(Path(path).expanduser().resolve()); grants=self.store.get_meta('file_grants',[])
        grants=[x for x in grants if x['path']!=p]; self.store.set_meta('file_grants',grants); self.store.log('file_permission_revoked',{'path':p}); return True
    def ingest(self, path):
        p=Path(path).expanduser().resolve(strict=True)
        if not any(x['path']==str(p) and x.get('granted') for x in self.store.get_meta('file_grants',[])): raise PermissionError('file has not been explicitly granted')
        if not p.is_file() or p.stat().st_size>self.max_bytes: raise ValueError('not a regular file or exceeds configured size limit')
        if p.suffix.lower() not in {'.txt','.md','.rst','.py','.json','.csv','.log'}: raise ValueError('file type not allowed for text ingestion')
        content=p.read_text(encoding='utf-8',errors='replace')
        result=self.brain.learn(content,source=f'granted-file:{p.name}')
        self.store.log('granted_file_ingested',{'name':p.name,'bytes':p.stat().st_size})
        return result
