"""SQLite persistence for identity, knowledge, neurons, edges, feedback and activity."""
import json
import os
import sqlite3
import threading
import time
import uuid
from pathlib import Path


SCHEMA = """
CREATE TABLE IF NOT EXISTS meta (key TEXT PRIMARY KEY, value TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS knowledge (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  digest TEXT NOT NULL UNIQUE,
  text TEXT NOT NULL,
  source TEXT NOT NULL,
  terms TEXT NOT NULL,
  created_at REAL NOT NULL,
  last_seen REAL NOT NULL,
  seen_count INTEGER NOT NULL DEFAULT 1,
  feedback REAL NOT NULL DEFAULT 0.0
);
CREATE INDEX IF NOT EXISTS knowledge_created ON knowledge(created_at DESC);
CREATE TABLE IF NOT EXISTS neurons (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  neuron_key TEXT NOT NULL UNIQUE,
  kind TEXT NOT NULL CHECK(kind IN ('memory','concept')),
  label TEXT NOT NULL,
  terms TEXT NOT NULL,
  strength REAL NOT NULL DEFAULT 1.0,
  activation REAL NOT NULL DEFAULT 0.0,
  activation_count INTEGER NOT NULL DEFAULT 0,
  created_at REAL NOT NULL,
  last_activated REAL
);
CREATE INDEX IF NOT EXISTS neurons_kind ON neurons(kind);
CREATE TABLE IF NOT EXISTS edges (
  source_id INTEGER NOT NULL REFERENCES neurons(id) ON DELETE CASCADE,
  target_id INTEGER NOT NULL REFERENCES neurons(id) ON DELETE CASCADE,
  relation TEXT NOT NULL,
  weight REAL NOT NULL DEFAULT 1.0,
  seen_count INTEGER NOT NULL DEFAULT 1,
  created_at REAL NOT NULL,
  PRIMARY KEY(source_id, target_id, relation),
  CHECK(source_id <> target_id)
);
CREATE INDEX IF NOT EXISTS edges_source ON edges(source_id);
CREATE INDEX IF NOT EXISTS edges_target ON edges(target_id);
CREATE TABLE IF NOT EXISTS activity (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  timestamp REAL NOT NULL,
  event TEXT NOT NULL,
  detail TEXT NOT NULL DEFAULT '{}'
);
CREATE INDEX IF NOT EXISTS activity_timestamp ON activity(timestamp DESC);
CREATE TABLE IF NOT EXISTS resource_usage (
  day TEXT PRIMARY KEY,
  chars_ingested INTEGER NOT NULL DEFAULT 0,
  work_units INTEGER NOT NULL DEFAULT 0,
  queries INTEGER NOT NULL DEFAULT 0
);
"""


class OrganismStore:
    def __init__(self, home: str):
        self.home = Path(home).resolve()
        self.home.mkdir(parents=True, exist_ok=True)
        self.db_path = self.home / "organism.sqlite3"
        self.lock = threading.RLock()
        self.db = sqlite3.connect(self.db_path, check_same_thread=False, timeout=10)
        self.db.row_factory = sqlite3.Row
        with self.lock:
            self.db.execute("PRAGMA foreign_keys=ON")
            self.db.execute("PRAGMA journal_mode=WAL")
            self.db.execute("PRAGMA busy_timeout=10000")
            self.db.executescript(SCHEMA)
            # Upgrade databases created by earlier desktop-pet builds in place.
            neuron_columns = {row[1] for row in self.db.execute("PRAGMA table_info(neurons)")}
            if "activation" not in neuron_columns:
                self.db.execute("ALTER TABLE neurons ADD COLUMN activation REAL NOT NULL DEFAULT 0.0")
            self._init_identity()
            self.db.commit()

    def _init_identity(self):
        identity = self.get_meta("identity")
        if identity is None:
            identity = {"id": str(uuid.uuid4()), "name": "Aurelia", "created_at": time.time(), "generation": 1}
            self.set_meta("identity", identity)
        if self.get_meta("paused") is None:
            self.set_meta("paused", False)
        if self.get_meta("total_ingests") is None:
            self.set_meta("total_ingests", 0)

    def get_meta(self, key, default=None):
        with self.lock:
            row = self.db.execute("SELECT value FROM meta WHERE key=?", (key,)).fetchone()
            return json.loads(row[0]) if row else default

    def set_meta(self, key, value):
        self.db.execute("INSERT INTO meta(key,value) VALUES(?,?) ON CONFLICT(key) DO UPDATE SET value=excluded.value",
                        (key, json.dumps(value, ensure_ascii=False)))

    def log(self, event, detail=None):
        self.db.execute("INSERT INTO activity(timestamp,event,detail) VALUES(?,?,?)",
                        (time.time(), event[:80], json.dumps(detail or {}, ensure_ascii=False)[:4000]))

    def close(self):
        with self.lock:
            self.db.commit()
            self.db.close()

    def status(self):
        with self.lock:
            identity = self.get_meta("identity")
            counts = {r["kind"]: r["n"] for r in self.db.execute("SELECT kind,COUNT(*) n FROM neurons GROUP BY kind")}
            knowledge_count = self.db.execute("SELECT COUNT(*) FROM knowledge").fetchone()[0]
            edge_count = self.db.execute("SELECT COUNT(*) FROM edges").fetchone()[0]
            actives = self.db.execute("SELECT COUNT(*) FROM activity").fetchone()[0]
            bytes_db = self.db_path.stat().st_size if self.db_path.exists() else 0
            usage = self.get_usage()
            return {"identity": identity, "neurons": {"memory": counts.get("memory", 0), "concept": counts.get("concept", 0), "total": sum(counts.values())},
                    "knowledge_items": knowledge_count, "relationships": edge_count, "activity_events": actives,
                    "database_bytes": bytes_db, "paused": bool(self.get_meta("paused", False)), "resource_usage": usage}

    def get_usage(self, day=None):
        from .resources import utc_day
        day = day or utc_day()
        with self.lock:
            row = self.db.execute("SELECT day,chars_ingested,work_units,queries FROM resource_usage WHERE day=?", (day,)).fetchone()
            if not row:
                return {"day": day, "chars_ingested": 0, "work_units": 0, "queries": 0}
            return dict(row)

    def add_usage(self, day, chars=0, work=0, queries=0):
        self.db.execute("INSERT INTO resource_usage(day,chars_ingested,work_units,queries) VALUES(?,?,?,?) "
                        "ON CONFLICT(day) DO UPDATE SET chars_ingested=chars_ingested+excluded.chars_ingested, "
                        "work_units=work_units+excluded.work_units, queries=queries+excluded.queries",
                        (day, chars, work, queries))

    def log_rows(self, limit=30):
        with self.lock:
            return [dict(r) for r in self.db.execute("SELECT id,timestamp,event,detail FROM activity ORDER BY id DESC LIMIT ?", (limit,))]

    def neurons_rows(self, limit=150):
        out = []
        with self.lock:
            for r in self.db.execute("SELECT id,neuron_key,kind,label,terms,strength,activation,activation_count,created_at,last_activated FROM neurons ORDER BY strength DESC,id DESC LIMIT ?", (limit,)):
                d = dict(r); d["terms"] = json.loads(d["terms"]); out.append(d)
        return out

    def edge_rows(self, limit=300):
        with self.lock:
            rows = self.db.execute("SELECT e.source_id,e.target_id,e.relation,e.weight,e.seen_count,a.label source_label,b.label target_label "
                                   "FROM edges e JOIN neurons a ON a.id=e.source_id JOIN neurons b ON b.id=e.target_id "
                                   "ORDER BY e.weight DESC LIMIT ?", (limit,)).fetchall()
            return [dict(r) for r in rows]

    def knowledge_rows(self, limit=100):
        out = []
        with self.lock:
            for r in self.db.execute("SELECT id,digest,text,source,terms,created_at,last_seen,seen_count,feedback FROM knowledge ORDER BY last_seen DESC LIMIT ?", (limit,)):
                d = dict(r); d["terms"] = json.loads(d["terms"]); out.append(d)
        return out
