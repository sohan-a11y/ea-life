"""Persistent, bounded goal lifecycle. Planning is advisory; no external action is executed."""
import time, uuid

class GoalManager:
    def __init__(self, store): self.store=store
    def list(self): return self.store.get_meta('managed_goals', []) or []
    def create(self, title, success_criteria='', priority=3, requires_approval=True):
        title=str(title).strip()[:240]
        if not title: raise ValueError('goal title required')
        goals=self.list()
        if len([g for g in goals if g['status'] in ('pending','in_progress')]) >= 100: raise ValueError('active goal limit reached')
        g={'id':str(uuid.uuid4()),'title':title,'success_criteria':str(success_criteria).strip()[:500], 'priority':max(1,min(5,int(priority))), 'requires_approval':bool(requires_approval),'status':'pending','created_at':time.time(),'updated_at':time.time(),'notes':[]}
        goals.append(g); self.store.set_meta('managed_goals',goals); self.store.log('goal_created',{'id':g['id'],'priority':g['priority']}); return g
    def update(self, goal_id, status=None, note=None):
        allowed={'pending','in_progress','blocked','completed','cancelled'}
        goals=self.list(); g=next((x for x in goals if x['id']==goal_id),None)
        if not g: raise KeyError('goal not found')
        if status is not None:
            if status not in allowed: raise ValueError('invalid goal status')
            g['status']=status
        if note:
            g['notes'].append({'text':str(note)[:1000],'at':time.time()}); g['notes']=g['notes'][-50:]
        g['updated_at']=time.time(); self.store.set_meta('managed_goals',goals); self.store.log('goal_updated',{'id':goal_id,'status':g['status']}); return g
    def next(self):
        active=[g for g in self.list() if g['status'] in ('pending','in_progress')]
        return sorted(active,key=lambda g:(-g['priority'],g['created_at']))[0] if active else None
