"""Supervise each non-primary colony member in its own Python process.

This is process-level lifecycle isolation, not an OS security sandbox. Child organisms
only run bounded cognition and report inbox counts; they never execute inbox messages.
"""
from __future__ import annotations

import json
import os
import subprocess
import sys
import tempfile
import threading
import time
from pathlib import Path
from typing import Any


def _read_json(path: Path, default: Any) -> Any:
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError, ValueError):
        return default


def _atomic_json(path: Path, payload: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    fd, temp = tempfile.mkstemp(prefix=path.stem + "-", suffix=".tmp", dir=str(path.parent))
    try:
        with os.fdopen(fd, "w", encoding="utf-8") as stream:
            json.dump(payload, stream, indent=2, ensure_ascii=False)
            stream.flush()
            os.fsync(stream.fileno())
        os.replace(temp, path)
    finally:
        try:
            if os.path.exists(temp):
                os.unlink(temp)
        except OSError:
            pass


class ColonyRuntimeSupervisor:
    """Start, pause, stop, monitor and restart child organism processes.

    Desired states are persisted so children previously marked running are relaunched
    when the owner desktop app is opened again. The primary organism is excluded because
    it runs in the UI process already.
    """
    ACTIVE = {"running", "paused"}

    def __init__(self, colony, project_root: str | Path | None = None,
                 restart_limit: int = 3, restart_window_seconds: float = 300.0):
        self.colony = colony
        self.home = Path(colony.home).resolve()
        self.project_root = Path(project_root or Path(__file__).resolve().parents[1]).resolve()
        self.controls = self.home / "runtime_controls"
        self.controls.mkdir(parents=True, exist_ok=True)
        self.heartbeat_path = self.home / "supervisor_heartbeat.json"
        self.desired_path = self.home / "runtime_desired.json"
        self._lock = threading.RLock()
        self._processes: dict[str, subprocess.Popen] = {}
        self._restart_times: dict[str, list[float]] = {}
        self._restart_limit = max(0, int(restart_limit))
        self._restart_window = max(30.0, float(restart_window_seconds))
        self._started = False
        self._closing = False
        self._desired = _read_json(self.desired_path, {})
        if not isinstance(self._desired, dict):
            self._desired = {}
        self._publish_heartbeat()

    def _control_path(self, organism_id: str) -> Path:
        return self.controls / f"{organism_id}.json"

    def _status_path(self, row: dict) -> Path:
        return Path(row["home"]) / "runtime_status.json"

    def _publish_heartbeat(self) -> None:
        _atomic_json(self.heartbeat_path, {"pid": os.getpid(), "timestamp": time.time(), "alive": True})

    def _save_desired(self) -> None:
        _atomic_json(self.desired_path, self._desired)

    def _write_control(self, organism_id: str, state: str) -> None:
        _atomic_json(self._control_path(organism_id), {"organism_id": organism_id, "state": state, "timestamp": time.time()})

    def start(self) -> None:
        """Start supervision and restore child processes whose desired state is active."""
        with self._lock:
            if self._started:
                return
            self._started = True
            self._closing = False
            self._publish_heartbeat()
            known = {r["id"] for r in self.colony.list() if not r.get("primary")}
            # Drop persisted settings for records that were deleted externally.
            self._desired = {oid: state for oid, state in self._desired.items() if oid in known}
            self._save_desired()
            for row in self.colony.list():
                if row.get("primary"):
                    continue
                state = self._desired.get(row["id"], "stopped")
                if state in self.ACTIVE:
                    self._write_control(row["id"], state)
                    self._spawn(row, reason="restore")
                else:
                    self._write_control(row["id"], "stopped")

    def start_organism(self, organism_id: str) -> dict:
        with self._lock:
            row = self._find_child(organism_id)
            self._desired[organism_id] = "running"
            self._save_desired()
            self._write_control(organism_id, "running")
            proc = self._processes.get(organism_id)
            if proc is None or proc.poll() is not None:
                # An explicit user start is the recovery action after a crash-loop lockout.
                self._restart_times[organism_id] = []
                proc = self._spawn(row, reason="manual-start")
            return {"id": organism_id, "desired_state": "running", "pid": proc.pid if proc else None}

    def start_all(self) -> list[dict]:
        return [self.start_organism(row["id"]) for row in self.colony.list() if not row.get("primary")]

    def pause_organism(self, organism_id: str) -> dict:
        with self._lock:
            self._find_child(organism_id)
            self._desired[organism_id] = "paused"
            self._save_desired()
            self._write_control(organism_id, "paused")
            return {"id": organism_id, "desired_state": "paused"}

    def resume_organism(self, organism_id: str) -> dict:
        return self.start_organism(organism_id)

    def stop_organism(self, organism_id: str, timeout: float = 4.0) -> dict:
        with self._lock:
            self._find_child(organism_id)
            self._desired[organism_id] = "stopped"
            self._save_desired()
            self._write_control(organism_id, "stopped")
            proc = self._processes.get(organism_id)
        if proc is not None and proc.poll() is None:
            try:
                proc.wait(timeout=max(0.1, timeout))
            except subprocess.TimeoutExpired:
                proc.terminate()
                try:
                    proc.wait(timeout=2.0)
                except subprocess.TimeoutExpired:
                    proc.kill()
                    proc.wait(timeout=2.0)
        with self._lock:
            self._processes.pop(organism_id, None)
            return {"id": organism_id, "desired_state": "stopped", "returncode": proc.poll() if proc else None}

    def stop_all(self, timeout: float = 5.0) -> list[dict]:
        """Stop all children against one shared deadline (not timeout per child)."""
        children = [row for row in self.colony.list() if not row.get("primary")]
        deadline = time.time() + max(0.1, float(timeout))
        with self._lock:
            processes = {}
            for row in children:
                oid = row["id"]
                self._desired[oid] = "stopped"
                self._write_control(oid, "stopped")
                processes[oid] = self._processes.get(oid)
            self._save_desired()
        for proc in processes.values():
            if proc is not None and proc.poll() is None:
                try:
                    proc.wait(timeout=max(0.05, deadline - time.time()))
                except subprocess.TimeoutExpired:
                    pass
        for proc in processes.values():
            if proc is not None and proc.poll() is None:
                try:
                    proc.terminate()
                    proc.wait(timeout=1.0)
                except subprocess.TimeoutExpired:
                    proc.kill()
                    try: proc.wait(timeout=1.0)
                    except subprocess.TimeoutExpired: pass
        with self._lock:
            for row in children:
                self._processes.pop(row["id"], None)
        return [{"id": row["id"], "desired_state": "stopped",
                 "returncode": processes[row["id"]].poll() if processes[row["id"]] else None}
                for row in children]

    def _find_child(self, organism_id: str) -> dict:
        for row in self.colony.list():
            if row["id"] == organism_id:
                if row.get("primary"):
                    raise ValueError("The primary organism runs inside the desktop application and is not managed as a child process.")
                return row
        raise KeyError("organism not found")

    def _spawn(self, row: dict, reason: str) -> subprocess.Popen | None:
        organism_id = row["id"]
        existing = self._processes.get(organism_id)
        if existing is not None and existing.poll() is None:
            return existing
        if self._closing:
            return None
        now = time.time()
        events = [stamp for stamp in self._restart_times.get(organism_id, []) if now - stamp <= self._restart_window]
        if events and len(events) >= self._restart_limit:
            # Preserve the last worker diagnostics instead of hiding them in crash-loop.
            previous = _read_json(self._status_path(row), {})
            status = {
                "organism_id": organism_id,
                "state": "crash-loop",
                "desired_state": "failed",
                "timestamp": now,
                "error": f"Restart limit reached ({self._restart_limit} within {int(self._restart_window)} seconds). Stop and explicitly start to retry.",
                "last_worker_state": previous.get("state"),
                "last_worker_error": previous.get("last_error") or previous.get("error"),
                "last_worker_traceback": previous.get("traceback"),
                "last_worker_pid": previous.get("pid"),
                "last_worker_exit_reason": previous.get("exit_reason"),
            }
            _atomic_json(self._status_path(row), status)
            self._desired[organism_id] = "failed"
            self._save_desired()
            return None
        if reason not in ("restore", "manual-start"):
            events.append(now)
            self._restart_times[organism_id] = events
        self._write_control(organism_id, self._desired.get(organism_id, "running"))
        stdout_path = Path(row["home"]) / "runtime_worker_process.log"
        stdout_path.parent.mkdir(parents=True, exist_ok=True)
        flags = getattr(subprocess, "CREATE_NO_WINDOW", 0) if os.name == "nt" else 0
        command = [sys.executable, "-m", "organism.worker", "--home", row["home"], "--organism-id", organism_id,
                   "--colony-home", str(self.home), "--control", str(self._control_path(organism_id)),
                   "--heartbeat", str(self.heartbeat_path), "--supervisor-pid", str(os.getpid()), "--tick-seconds", "3"]
        try:
            with open(stdout_path, "a", encoding="utf-8") as log_file:
                proc = subprocess.Popen(command, cwd=str(self.project_root), stdin=subprocess.DEVNULL,
                                        stdout=log_file, stderr=subprocess.STDOUT, creationflags=flags,
                                        close_fds=True)
            self._processes[organism_id] = proc
            return proc
        except Exception as exc:
            _atomic_json(self._status_path(row), {"organism_id": organism_id, "state": "launch-failed", "timestamp": time.time(), "error": str(exc)[:300]})
            return None

    def poll(self) -> list[dict]:
        """Publish heartbeat and restart unexpectedly exited active children when safe."""
        with self._lock:
            self._publish_heartbeat()
            rows = self.colony.list()
            for row in rows:
                if row.get("primary"):
                    continue
                oid = row["id"]
                desired = self._desired.get(oid, "stopped")
                proc = self._processes.get(oid)
                if desired in self.ACTIVE and (proc is None or proc.poll() is not None) and not self._closing:
                    # If the process previously ran, treat a relaunch as a supervised restart.
                    self._spawn(row, reason="unexpected-exit" if proc is not None else "missing-worker")
            result = []
            for row in rows:
                oid = row["id"]
                if row.get("primary"):
                    result.append({**row, "runtime_state": "embedded", "desired_state": "running", "pid": os.getpid(), "alive": True})
                    continue
                proc = self._processes.get(oid)
                status = _read_json(self._status_path(row), {})
                desired = self._desired.get(oid, "stopped")
                alive = bool(proc is not None and proc.poll() is None)
                if alive:
                    runtime_state = status.get("state", "starting")
                elif desired == "stopped":
                    runtime_state = "stopped"
                else:
                    runtime_state = status.get("state", "not-running")
                result.append({**row, "runtime_state": runtime_state, "desired_state": desired,
                               "pid": proc.pid if alive else status.get("pid"), "alive": alive,
                               "last_heartbeat": status.get("last_heartbeat"), "cycle_count": status.get("cycle_count", 0),
                               "reflection_count": status.get("reflection_count", 0), "pending_inbox": status.get("pending_inbox", 0),
                               "last_error": status.get("last_error") or status.get("error")})
            return result

    def close(self, timeout: float = 3.0) -> None:
        """Stop child processes on UI exit but preserve desired states for next launch."""
        with self._lock:
            self._closing = True
            processes = list(self._processes.items())
            for oid, proc in processes:
                self._write_control(oid, "shutdown")
        deadline = time.time() + max(0.1, timeout)
        for _, proc in processes:
            if proc.poll() is None:
                try:
                    proc.wait(timeout=max(0.1, deadline - time.time()))
                except subprocess.TimeoutExpired:
                    proc.terminate()
        for _, proc in processes:
            if proc.poll() is None:
                try:
                    proc.wait(timeout=1.5)
                except subprocess.TimeoutExpired:
                    proc.kill()
        self._processes.clear()
        _atomic_json(self.heartbeat_path, {"pid": os.getpid(), "timestamp": time.time(), "alive": False})

    def desired_states(self) -> dict[str, str]:
        return dict(self._desired)
