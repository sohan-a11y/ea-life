"""Small adaptive recurrent substrate with bounded online Oja-style plasticity.

This is a lightweight experimental neural dynamical system, not a pretrained model
and not a claim of consciousness. It runs on the Python standard library only.
"""
from __future__ import annotations

import hashlib
import math
import random
import re
import time
from typing import Any


class AdaptiveSubstrate:
    UNITS = 24
    FEATURES = 24
    MICRO_STEPS = 3
    LEARNING_RATE = 0.004
    MAX_WEIGHT = 0.65

    def __init__(self, store):
        self.store = store
        identity = store.get_meta("identity", {}) or {}
        seed = int(hashlib.sha256(str(identity.get("id", "alife")).encode()).hexdigest()[:12], 16)
        rng = random.Random(seed)
        with store.lock, store.db:
            if store.get_meta("adaptive_substrate_version") != 1:
                store.set_meta("adaptive_substrate_version", 1)
                store.set_meta("adaptive_recurrent_weights", [[round(rng.uniform(-0.04, 0.04), 6) for _ in range(self.UNITS)] for _ in range(self.UNITS)])
                store.set_meta("adaptive_input_weights", [[round(rng.uniform(-0.4, 0.4), 6) for _ in range(self.FEATURES)] for _ in range(self.UNITS)])
                store.set_meta("adaptive_state", [0.0] * self.UNITS)
                store.set_meta("adaptive_metrics", {"updates": 0, "inferences": 0, "last_mean_activation": 0.0, "last_update_at": None})
                store.log("adaptive_substrate_initialized", {"units": self.UNITS, "features": self.FEATURES})

    def encode(self, text: str) -> list[float]:
        features = [0.0] * self.FEATURES
        tokens = re.findall(r"[a-zA-Z][a-zA-Z0-9_]{1,}|[0-9]{2,}", str(text).lower())[:400]
        if not tokens:
            return features
        for token in tokens:
            digest = hashlib.blake2b(token.encode("utf-8"), digest_size=8).digest()
            index = int.from_bytes(digest[:4], "big") % self.FEATURES
            sign = 1.0 if digest[4] & 1 else -1.0
            features[index] += sign
        scale = math.sqrt(sum(x * x for x in features)) or 1.0
        return [x / scale for x in features]

    @staticmethod
    def _tanh(value: float) -> float:
        return math.tanh(max(-8.0, min(8.0, value)))

    def _rollout(self, features: list[float], recurrent: list[list[float]], inputs: list[list[float]], initial: list[float] | None = None) -> list[float]:
        state = list(initial or [0.0] * self.UNITS)
        for _ in range(self.MICRO_STEPS):
            next_state = []
            for i in range(self.UNITS):
                drive = sum(inputs[i][j] * features[j] for j in range(self.FEATURES))
                recurrence = sum(recurrent[i][j] * state[j] for j in range(self.UNITS))
                next_state.append(self._tanh(drive + recurrence))
            state = next_state
        return state

    def process(self, text: str, learn: bool = False) -> dict[str, Any]:
        if self.store.get_meta("paused", False):
            return {"skipped": "paused"}
        features = self.encode(text)
        if not any(features):
            return {"skipped": "no_features"}
        with self.store.lock, self.store.db:
            recurrent = self.store.get_meta("adaptive_recurrent_weights")
            inputs = self.store.get_meta("adaptive_input_weights")
            state = self.store.get_meta("adaptive_state")
            metrics = self.store.get_meta("adaptive_metrics", {}) or {}
            output = self._rollout(features, recurrent, inputs, state)
            if learn:
                # Oja-style local update keeps each weight bounded and uses only this
                # activation episode; there is no backpropagation or claim of semantics.
                for i in range(self.UNITS):
                    hi = output[i]
                    for j in range(self.UNITS):
                        old = recurrent[i][j]
                        delta = self.LEARNING_RATE * hi * (output[j] - hi * old)
                        recurrent[i][j] = round(max(-self.MAX_WEIGHT, min(self.MAX_WEIGHT, old + delta)), 6)
                    for j in range(self.FEATURES):
                        old = inputs[i][j]
                        delta = (self.LEARNING_RATE * 0.25) * hi * (features[j] - hi * old)
                        inputs[i][j] = round(max(-self.MAX_WEIGHT, min(self.MAX_WEIGHT, old + delta)), 6)
                metrics["updates"] = int(metrics.get("updates", 0)) + 1
                metrics["last_update_at"] = time.time()
                self.store.set_meta("adaptive_recurrent_weights", recurrent)
                self.store.set_meta("adaptive_input_weights", inputs)
            else:
                metrics["inferences"] = int(metrics.get("inferences", 0)) + 1
            self.store.set_meta("adaptive_state", [round(x, 6) for x in output])
            metrics["last_mean_activation"] = round(sum(abs(x) for x in output) / len(output), 6)
            self.store.set_meta("adaptive_metrics", metrics)
            return {"units": self.UNITS, "mean_abs_activation": metrics["last_mean_activation"], "learned": bool(learn), "updates": metrics.get("updates", 0)}

    def resonance(self, left: str, right: str) -> float:
        """Experimental cosine similarity between reset-state recurrent responses."""
        recurrent = self.store.get_meta("adaptive_recurrent_weights")
        inputs = self.store.get_meta("adaptive_input_weights")
        a = self._rollout(self.encode(left), recurrent, inputs)
        b = self._rollout(self.encode(right), recurrent, inputs)
        dot = sum(x * y for x, y in zip(a, b))
        norm_a = math.sqrt(sum(x * x for x in a))
        norm_b = math.sqrt(sum(x * x for x in b))
        if norm_a <= 1e-12 or norm_b <= 1e-12:
            return 0.0
        return max(-1.0, min(1.0, dot / (norm_a * norm_b)))

    def report(self) -> dict[str, Any]:
        metrics = self.store.get_meta("adaptive_metrics", {}) or {}
        state = self.store.get_meta("adaptive_state", []) or []
        recurrent = self.store.get_meta("adaptive_recurrent_weights", []) or []
        input_weights = self.store.get_meta("adaptive_input_weights", []) or []
        values = [abs(x) for row in recurrent for x in row]
        inp_values = [abs(x) for row in input_weights for x in row]
        return {
            "type": "small recurrent reservoir with local Oja-style online plasticity",
            "units": self.UNITS,
            "micro_steps_per_input": self.MICRO_STEPS,
            "plasticity_updates": int(metrics.get("updates", 0)),
            "inference_calls": int(metrics.get("inferences", 0)),
            "mean_absolute_activation": metrics.get("last_mean_activation", 0.0),
            "mean_absolute_recurrent_weight": round(sum(values) / max(1, len(values)), 6),
            "mean_absolute_input_weight": round(sum(inp_values) / max(1, len(inp_values)), 6),
            "state_l2_norm": round(math.sqrt(sum(x * x for x in state)), 6),
            "last_update_at": metrics.get("last_update_at"),
            "limitations": ["not pretrained", "hashed lexical input features are not semantic embeddings", "no gradient-based language training", "small experimental substrate; not evidence of consciousness"],
        }
