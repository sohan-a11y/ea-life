"""Application-level resource accounting; these are budgets, not OS sandbox limits."""
from dataclasses import dataclass
from datetime import datetime, timezone


@dataclass(frozen=True)
class ResourceLimits:
    max_input_chars: int = 20_000
    max_sentences_per_ingest: int = 80
    daily_char_budget: int = 100_000
    daily_work_budget: int = 10_000
    max_query_chars: int = 1_000
    max_context_chars: int = 8_000


class ResourceBudgetExceeded(ValueError):
    pass


def utc_day() -> str:
    return datetime.now(timezone.utc).strftime("%Y-%m-%d")


def estimate_work_units(chars: int, sentences: int) -> int:
    """A simple reproducible work proxy, not CPU time or energy consumption."""
    return max(1, (max(0, chars) + 99) // 100 + max(0, sentences) * 2)
