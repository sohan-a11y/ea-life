"""Bounded internal regulation and scheduled reflection for the desktop organism.

These numeric variables are engineering controls, not evidence of felt emotions.
"""
from __future__ import annotations

import time
from typing import Any

from .resources import utc_day


DEFAULT_STATE = {
    "energy": 100.0,
    "curiosity": 35.0,
    "stability": 80.0,
    "cycle_count": 0,
    "reflection_count": 0,
    "reflection_day": "",
    "reflections_today": 0,
    "created_runtime_at": time.time(),
    "last_tick_at": 0.0,
    "last_reflection_at": 0.0,
    "last_event_at": time.time(),
    "last_event": "created",
    "last_cycle_summary": "No cognitive cycles have run yet.",
}


class LifeController:
    """Small, deterministic, resource-bounded internal-state controller."""

    def __init__(self, store, brain, reflection_interval_seconds: float = 300.0):
        self.store = store
        self.brain = brain
        self.reflection_interval_seconds = max(15.0, float(reflection_interval_seconds))
        with self.store.lock, self.store.db:
            state = self.store.get_meta("life_state")
            if not isinstance(state, dict):
                state = dict(DEFAULT_STATE)
                self.store.set_meta("life_state", state)
                self.store.log("life_state_initialized", {"controller": "bounded-v1"})

    def state(self) -> dict[str, Any]:
        state = dict(DEFAULT_STATE)
        saved = self.store.get_meta("life_state", {})
        if isinstance(saved, dict):
            state.update(saved)
        return state

    def note_event(self, event: str) -> None:
        state = self.state()
        state["last_event_at"] = time.time()
        state["last_event"] = str(event)[:80]
        state["curiosity"] = round(min(100.0, float(state["curiosity"]) + 4.0), 2)
        # Interactions restore a little energy because the system was already awake for them.
        state["energy"] = round(min(100.0, float(state["energy"]) + 1.0), 2)
        with self.store.lock, self.store.db:
            self.store.set_meta("life_state", state)

    def tick(self, force_reflection: bool = False) -> dict[str, Any]:
        """Advance state once; at most one small reflection pass is run per tick."""
        now = time.time()
        state = self.state()
        if self.store.get_meta("paused", False):
            return {**state, "paused": True, "cycle": None}

        last_tick = float(state.get("last_tick_at", 0.0) or 0.0)
        elapsed = max(0.0, min(now - last_tick, 300.0)) if last_tick else 0.0
        # Internal controls move slowly and are clamped. They are not biological energy.
        state["energy"] = round(max(0.0, min(100.0, float(state["energy"]) + min(elapsed / 60.0, 1.0) * 0.8)), 2)
        idle_minutes = max(0.0, (now - float(state.get("last_event_at", now) or now)) / 60.0)
        state["curiosity"] = round(max(0.0, min(100.0, float(state["curiosity"]) + min(idle_minutes, 1.0) * 0.25)), 2)
        state["last_tick_at"] = now
        state["cycle_count"] = int(state.get("cycle_count", 0)) + 1

        today = utc_day()
        if state.get("reflection_day") != today:
            state["reflection_day"] = today
            state["reflections_today"] = 0
        reflection_due = force_reflection or (
            now - float(state.get("last_reflection_at", 0.0) or 0.0) >= self.reflection_interval_seconds
            and float(state["curiosity"]) >= 25.0
        )
        cycle_result = None
        # Hard cap on background/manual reflection passes protects idle CPU usage.
        daily_cap = 288
        under_daily_cap = int(state.get("reflections_today", 0)) < daily_cap
        if reflection_due and under_daily_cap and float(state["energy"]) >= 10.0:
            # If the data-quality score is low, make fewer speculative association links.
            association_cap = 5 if float(state["stability"]) >= 40.0 else 2
            cycle_result = self.brain.reflect(max_memories=30, max_new_associations=association_cap)
            state["energy"] = round(max(0.0, float(state["energy"]) - (3.0 if cycle_result.get("memories_examined", 0) else 1.0)), 2)
            state["curiosity"] = round(max(0.0, float(state["curiosity"]) - 2.0), 2)
            state["last_reflection_at"] = now
            state["reflection_count"] = int(state.get("reflection_count", 0)) + 1
            state["reflections_today"] = int(state.get("reflections_today", 0)) + 1
            state["last_cycle_summary"] = (
                f"Examined {cycle_result.get('memories_examined', 0)} memories; "
                f"added {cycle_result.get('new_associations', 0)} association(s)."
            )
            # This is a bookkeeping indicator of unresolved data quality, not psychological stability.
            conflicts = int(cycle_result.get("potential_conflicts", 0))
            state["stability"] = round(max(0.0, min(100.0, 100.0 - min(conflicts, 100) * 1.5)), 2)
            with self.store.lock, self.store.db:
                self.store.log("cognitive_cycle", {**cycle_result, "cycle_count": state["cycle_count"], "reflections_today": state["reflections_today"], "daily_cap": daily_cap})
        elif reflection_due and not under_daily_cap:
            state["last_cycle_summary"] = f"Daily reflection cap reached ({daily_cap} passes); background reflection is resting until tomorrow."
        with self.store.lock, self.store.db:
            self.store.set_meta("life_state", state)
        return {**state, "paused": False, "cycle": cycle_result}
