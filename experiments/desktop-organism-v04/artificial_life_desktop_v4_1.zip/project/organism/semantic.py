"""Optional local Ollama semantic embeddings with persistent SQLite caching.

Nothing is sent to a hosted endpoint: this module only targets loopback Ollama.
"""
from __future__ import annotations

import json
import math
import os
import time
import urllib.request
from urllib.error import URLError, HTTPError

import hashlib
import re

def digest_sentence(text: str) -> str:
    normalized = re.sub(r"\s+", " ", str(text)).strip().casefold()
    return hashlib.sha256(normalized.encode("utf-8")).hexdigest()


class LocalSemanticMemory:
    def __init__(self, store, model: str | None = None):
        self.store = store
        self.model = (model if model is not None else os.environ.get("ALIFE_OLLAMA_EMBED_MODEL", "")).strip()
        with store.lock:
            store.db.execute("CREATE TABLE IF NOT EXISTS semantic_embeddings (digest TEXT PRIMARY KEY, model TEXT NOT NULL, vector TEXT NOT NULL, updated_at REAL NOT NULL)")
            store.db.execute("CREATE INDEX IF NOT EXISTS semantic_embeddings_model ON semantic_embeddings(model)")
            store.db.commit()

    @property
    def enabled(self) -> bool:
        return bool(self.model)

    def _embed(self, texts: list[str]) -> list[list[float]]:
        if not self.model:
            raise RuntimeError("Set ALIFE_OLLAMA_EMBED_MODEL to enable local semantic embeddings.")
        texts = [str(x)[:4000] for x in texts[:64]]
        if not texts:
            return []
        payload = json.dumps({"model": self.model, "input": texts}).encode("utf-8")
        request = urllib.request.Request("http://127.0.0.1:11434/api/embed", data=payload, headers={"Content-Type": "application/json"}, method="POST")
        class NoRedirect(urllib.request.HTTPRedirectHandler):
            def redirect_request(self, req, fp, code, msg, headers, newurl):
                return None
        try:
            opener = urllib.request.build_opener(NoRedirect)
            with opener.open(request, timeout=20) as response:
                data = json.loads(response.read(4_000_000).decode("utf-8"))
        except (URLError, HTTPError, TimeoutError, ValueError) as exc:
            raise RuntimeError(f"Local Ollama embedding request failed: {str(exc)[:160]}") from exc
        vectors = data.get("embeddings")
        if not isinstance(vectors, list) or len(vectors) != len(texts):
            raise RuntimeError("Ollama returned an unexpected embedding response")
        clean = []
        dimension = None
        for vector in vectors:
            if not isinstance(vector, list) or not vector or len(vector) > 16384:
                raise RuntimeError("Ollama returned an invalid embedding vector")
            vector = [float(value) for value in vector]
            if not all(math.isfinite(value) for value in vector):
                raise RuntimeError("Ollama returned non-finite embedding values")
            if dimension is not None and len(vector) != dimension:
                raise RuntimeError("Ollama returned inconsistent embedding dimensions")
            dimension = len(vector)
            clean.append(vector)
        return clean

    def pending_rows(self, rows, limit: int = 100) -> list[dict]:
        if not self.enabled:
            return []
        limit = max(1, min(int(limit), 500))
        pending = []
        with self.store.lock:
            for row in rows:
                digest = row.get("digest") or digest_sentence(row["text"])
                cached = self.store.db.execute("SELECT 1 FROM semantic_embeddings WHERE digest=? AND model=?", (digest, self.model)).fetchone()
                if not cached:
                    pending.append(row)
                    if len(pending) >= limit:
                        break
        return pending

    def index_rows(self, rows, limit: int = 100) -> dict:
        """Index at most `limit` knowledge rows, in bounded batches; returns cache counts."""
        if not self.enabled:
            raise RuntimeError("Semantic indexing is off. Set ALIFE_OLLAMA_EMBED_MODEL first.")
        limit = max(1, min(int(limit), 500))
        rows = rows[:limit]
        missing = []
        for row in rows:
            digest = row.get("digest") or digest_sentence(row["text"])
            cached = self.store.db.execute("SELECT 1 FROM semantic_embeddings WHERE digest=? AND model=?", (digest, self.model)).fetchone()
            if not cached:
                missing.append((digest, row["text"]))
        added = 0
        for start in range(0, len(missing), 32):
            batch = missing[start:start + 32]
            vectors = self._embed([text for _, text in batch])
            with self.store.lock, self.store.db:
                for (digest, _), vector in zip(batch, vectors):
                    self.store.db.execute("INSERT INTO semantic_embeddings(digest,model,vector,updated_at) VALUES(?,?,?,?) ON CONFLICT(digest) DO UPDATE SET model=excluded.model,vector=excluded.vector,updated_at=excluded.updated_at", (digest, self.model, json.dumps(vector, separators=(",", ":")), time.time()))
                    added += 1
                self.store.log("semantic_index_batch", {"model": self.model, "added": len(batch)})
        total = self.store.db.execute("SELECT COUNT(*) FROM semantic_embeddings WHERE model=?", (self.model,)).fetchone()[0]
        return {"processed": len(rows), "new_embeddings": added, "cached_embeddings": total, "model": self.model}

    @staticmethod
    def cosine(a: list[float], b: list[float]) -> float:
        if len(a) != len(b) or not a:
            return 0.0
        dot = sum(x * y for x, y in zip(a, b))
        na = math.sqrt(sum(x * x for x in a)); nb = math.sqrt(sum(x * x for x in b))
        return dot / (na * nb) if na > 0 and nb > 0 else 0.0

    def rank(self, query: str, rows: list[dict], limit: int = 5) -> list[dict]:
        if not self.enabled:
            return []
        vector = self._embed([query])[0]
        with self.store.lock:
            cached = {r["digest"]: json.loads(r["vector"]) for r in self.store.db.execute("SELECT digest,vector FROM semantic_embeddings WHERE model=?", (self.model,))}
        ranked = []
        for row in rows:
            digest = row.get("digest") or digest_sentence(row["text"])
            candidate = cached.get(digest)
            if candidate is not None and len(candidate) == len(vector):
                ranked.append({"digest": digest, "similarity": self.cosine(vector, candidate)})
        ranked.sort(key=lambda x: x["similarity"], reverse=True)
        return ranked[:max(1, min(int(limit), 50))]

    def status(self) -> dict:
        with self.store.lock:
            count = self.store.db.execute("SELECT COUNT(*) FROM semantic_embeddings WHERE model=?", (self.model,)).fetchone()[0] if self.model else 0
        return {"enabled": self.enabled, "model": self.model or None, "cached_items": count, "endpoint": "127.0.0.1:11434 only"}
