"""Local organism colony with isolated SQLite stores and authenticated encrypted inbox envelopes.

Messages are local-only. A shared Fernet key protects envelopes stored in local DBs; this
is not a network protocol and does not protect against an attacker who can read the
colony key or control the same user account.
"""
from pathlib import Path
import json
import os
import tempfile
import time
import uuid

from .store import OrganismStore
from .brain import Brain


class Colony:
    def __init__(self, home):
        self.home = Path(home).expanduser().resolve()
        self.home.mkdir(parents=True, exist_ok=True)
        self.index = self.home / "colony.json"
        self.key_path = self.home / "colony.key"
        self._fernet_instance = None
        if not self.index.exists():
            self._save([])

    def _load(self):
        try:
            rows = json.loads(self.index.read_text(encoding="utf-8"))
            if not isinstance(rows, list):
                raise ValueError("invalid colony index shape")
            return rows
        except (OSError, json.JSONDecodeError, ValueError):
            backup = self.index.with_suffix(".json.bak")
            if backup.exists():
                rows = json.loads(backup.read_text(encoding="utf-8"))
                if isinstance(rows, list):
                    return rows
            raise RuntimeError(f"Colony index is unreadable; inspect {self.index} and its backup")

    def _save(self, rows):
        payload = json.dumps(rows, indent=2, ensure_ascii=False)
        self.home.mkdir(parents=True, exist_ok=True)
        # Use replace to avoid leaving a half-written index on interruption.
        fd, temporary = tempfile.mkstemp(prefix="colony-", suffix=".tmp", dir=str(self.home))
        try:
            with os.fdopen(fd, "w", encoding="utf-8") as handle:
                handle.write(payload)
                handle.flush()
                os.fsync(handle.fileno())
            if self.index.exists():
                try:
                    self.index.replace(self.index.with_suffix(".json.bak"))
                except OSError:
                    pass
            os.replace(temporary, self.index)
        finally:
            try:
                if os.path.exists(temporary): os.unlink(temporary)
            except OSError:
                pass

    def _fernet(self):
        if self._fernet_instance is not None:
            return self._fernet_instance
        try:
            from cryptography.fernet import Fernet
        except ImportError as exc:
            raise RuntimeError("Colony message encryption requires `pip install cryptography`.") from exc
        if not self.key_path.exists():
            key = Fernet.generate_key()
            flags = os.O_WRONLY | os.O_CREAT | os.O_EXCL
            try:
                fd = os.open(self.key_path, flags, 0o600)
                with os.fdopen(fd, "wb") as handle:
                    handle.write(key); handle.flush(); os.fsync(handle.fileno())
            except FileExistsError:
                key = self.key_path.read_bytes()
            try:
                if os.name != "nt": os.chmod(self.key_path, 0o600)
            except OSError:
                pass
        else:
            key = self.key_path.read_bytes()
            try:
                if os.name != "nt" and self.key_path.stat().st_mode & 0o077:
                    os.chmod(self.key_path, 0o600)
            except OSError:
                pass
        self._fernet_instance = Fernet(key)
        return self._fernet_instance

    def security_status(self):
        try:
            self._fernet()
            return {"enabled": True, "method": "Fernet authenticated encryption", "scope": "local colony inbox files", "key_path": str(self.key_path), "network_transport": False}
        except Exception as exc:
            return {"enabled": False, "error": str(exc), "network_transport": False}

    def list(self):
        return self._load()

    def register_existing(self, home, identity=None):
        """Register the running primary organism so the creator console can address it."""
        folder = Path(home).expanduser().resolve()
        if identity is None:
            store = OrganismStore(str(folder))
            try: identity = store.get_meta("identity")
            finally: store.close()
        if not identity or not identity.get("id"):
            raise ValueError("existing organism identity is missing")
        rows = self._load()
        for row in rows:
            if row.get("id") == identity["id"]:
                row.update({"name": identity.get("name", row.get("name", "Organism")), "home": str(folder), "generation": identity.get("generation", 1), "parent_id": identity.get("parent_id")})
                self._save(rows)
                return row
        row = {"id": identity["id"], "name": identity.get("name", "Organism"), "generation": identity.get("generation", 1),
               "parent_id": identity.get("parent_id"), "home": str(folder), "created_at": identity.get("created_at", time.time()), "primary": True}
        rows.insert(0, row)
        self._save(rows)
        return row

    def create(self, name, parent_id=None, inherit_knowledge=False):
        name = str(name).strip()[:60]
        if not name: raise ValueError("name required")
        rows = self._load()
        parent = next((r for r in rows if r["id"] == parent_id), None) if parent_id else None
        if parent_id and not parent: raise KeyError("parent organism not found")
        oid = str(uuid.uuid4()); folder = self.home / "organisms" / oid; folder.mkdir(parents=True)
        store = OrganismStore(str(folder)); identity = store.get_meta("identity")
        identity.update({"id": oid, "name": name, "generation": (parent["generation"] + 1 if parent else 1), "parent_id": parent_id})
        store.set_meta("identity", identity)
        if inherit_knowledge and parent:
            source = OrganismStore(parent["home"])
            try:
                # Avoid hundreds of local embedding model calls during bulk inheritance;
                # child memory can be indexed later through its own UI/runtime.
                brain = Brain(store, semantic_autoindex=False)
                for item in reversed(source.knowledge_rows(limit=500)):
                    try: brain.learn(item["text"], source=f"inherited:{parent['name']}:{item['source']}")
                    except Exception: pass
            finally:
                source.close()
        store.log("organism_created", {"generation": identity["generation"], "parent_id": parent_id, "inherited": bool(inherit_knowledge and parent)})
        store.close()
        row = {"id": oid, "name": name, "generation": identity["generation"], "parent_id": parent_id, "home": str(folder), "created_at": time.time()}
        rows.append(row); self._save(rows)
        return row

    def deliver(self, organism_id, message, sender="creator"):
        row = next((r for r in self._load() if r["id"] == organism_id), None)
        if not row: raise KeyError("organism not found")
        message = str(message).strip()[:4000]
        if not message: raise ValueError("message cannot be empty")
        envelope_id, now = str(uuid.uuid4()), time.time()
        body = {"id": envelope_id, "sender": str(sender)[:80], "message": message, "at": now, "recipient": organism_id}
        token = self._fernet().encrypt(json.dumps(body, ensure_ascii=False).encode("utf-8")).decode("ascii")
        envelope = {"id": envelope_id, "token": token, "at": now, "read": False, "encrypted": True, "scheme": "fernet-v1"}
        store = OrganismStore(row["home"])
        try:
            inbox = store.get_meta("inbox", []) or []
            inbox.append(envelope); store.set_meta("inbox", inbox[-500:])
            store.log("colony_message_received", {"sender": body["sender"], "encrypted": True})
            store.db.commit()
            return envelope
        finally:
            store.close()

    def broadcast(self, message, sender="creator"):
        return [self.deliver(row["id"], message, sender) for row in self._load()]

    def read_inbox(self, organism_id, mark_read=False):
        row = next((r for r in self._load() if r["id"] == organism_id), None)
        if not row: raise KeyError("organism not found")
        store = OrganismStore(row["home"])
        try:
            inbox = store.get_meta("inbox", []) or []
            result = []
            for envelope in inbox:
                if envelope.get("encrypted"):
                    try:
                        from cryptography.fernet import InvalidToken
                        body = json.loads(self._fernet().decrypt(envelope["token"].encode("ascii")).decode("utf-8"))
                        body["read"] = bool(envelope.get("read", False))
                        body["encrypted"] = True
                        result.append(body)
                    except Exception:
                        result.append({"id": envelope.get("id", "unknown"), "sender": "unverified", "message": "Message failed authentication or cannot be decrypted.", "at": envelope.get("at"), "read": bool(envelope.get("read", False)), "encrypted": True, "invalid": True})
                else:
                    # Read-only compatibility for messages generated by early prototypes.
                    result.append(dict(envelope, legacy_plaintext=True))
            if mark_read:
                for item in inbox: item["read"] = True
                store.set_meta("inbox", inbox); store.db.commit()
            return list(reversed(result[-200:]))
        finally:
            store.close()
