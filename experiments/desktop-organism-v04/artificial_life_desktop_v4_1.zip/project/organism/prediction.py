"""Small, inspectable prediction-error memory; not a world model or consciousness claim."""
from __future__ import annotations
import time

class PredictionEngine:
    def __init__(self, store): self.store = store

    def predict(self, context: str, expected: str, confidence: float = 0.5) -> dict:
        context, expected = str(context).strip()[:1000], str(expected).strip()[:1000]
        if not context or not expected: raise ValueError('context and expected outcome are required')
        confidence = max(0.0, min(1.0, float(confidence)))
        predictions = self.store.get_meta('predictions', [])
        item = {'id': f"p-{time.time_ns()}", 'context': context, 'expected': expected, 'confidence': confidence, 'created_at': time.time(), 'status': 'pending'}
        predictions.append(item); self.store.set_meta('predictions', predictions[-500:])
        self.store.log('prediction_created', {'id': item['id'], 'confidence': confidence})
        return item

    def observe(self, prediction_id: str, observed: str) -> dict:
        predictions = self.store.get_meta('predictions', [])
        item = next((p for p in predictions if p['id'] == prediction_id), None)
        if item is None: raise KeyError('prediction not found')
        if item['status'] != 'pending': raise ValueError('prediction already evaluated')
        observed = str(observed).strip()[:1000]
        if not observed: raise ValueError('observed outcome is required')
        # Transparent lexical proxy only; human can inspect expected vs observed.
        exp = set(item['expected'].casefold().split()); obs = set(observed.casefold().split())
        similarity = len(exp & obs) / max(1, len(exp | obs))
        item.update({'observed': observed, 'similarity_proxy': round(similarity, 4), 'prediction_error_proxy': round(1-similarity, 4), 'status': 'evaluated', 'evaluated_at': time.time()})
        self.store.set_meta('predictions', predictions)
        self.store.log('prediction_evaluated', {'id': prediction_id, 'similarity_proxy': item['similarity_proxy']})
        return item

    def list(self, limit=50): return list(reversed(self.store.get_meta('predictions', [])[-max(1,min(int(limit),200)):]))
