"""Loopback-only administration server. API mutations require a bearer token."""
import hmac
import json
import os
import secrets
import sys
import threading
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import urlparse

from .brain import Brain
from .resources import ResourceBudgetExceeded, ResourceLimits
from .store import OrganismStore

PROJECT_ROOT = Path(__file__).resolve().parent.parent
WEB_ROOT = PROJECT_ROOT / "web"
MAX_BODY = 64 * 1024


def load_or_create_token(home: Path) -> tuple[str, bool]:
    token_path = home / "admin_token.txt"
    if token_path.exists():
        token = token_path.read_text(encoding="utf-8").strip()
        if len(token) < 32:
            raise RuntimeError(f"Admin token in {token_path} is unexpectedly short. Remove it to generate a new one.")
        return token, False
    token = secrets.token_urlsafe(36)
    home.mkdir(parents=True, exist_ok=True)
    token_path.write_text(token + "\n", encoding="utf-8")
    try:
        os.chmod(token_path, 0o600)
    except OSError:
        pass
    return token, True


class AlifeHTTPServer(ThreadingHTTPServer):
    daemon_threads = True
    allow_reuse_address = True


class Handler(BaseHTTPRequestHandler):
    server_version = "ArtificialLifeLocal/0.1"

    def log_message(self, fmt, *args):
        # Keep access tokens / query strings out of stdout; write concise app-level events instead.
        sys.stderr.write("[alife-http] " + (fmt % args) + "\n")

    @property
    def app(self):
        return self.server.app

    def _send(self, status, body, content_type="application/json; charset=utf-8"):
        raw = body if isinstance(body, bytes) else (body.encode("utf-8") if isinstance(body, str) else json.dumps(body, ensure_ascii=False).encode("utf-8"))
        self.send_response(status)
        self.send_header("Content-Type", content_type)
        self.send_header("Content-Length", str(len(raw)))
        self.send_header("Cache-Control", "no-store")
        self.send_header("X-Content-Type-Options", "nosniff")
        self.send_header("Referrer-Policy", "no-referrer")
        self.send_header("Content-Security-Policy", "default-src 'self'; script-src 'self'; style-src 'self'; connect-src 'self'; img-src 'self' data:; object-src 'none'; base-uri 'none'; frame-ancestors 'none'; form-action 'self'")
        self.end_headers()
        self.wfile.write(raw)

    def _authenticated(self):
        header = self.headers.get("Authorization", "")
        if not header.startswith("Bearer "):
            return False
        supplied = header[7:].strip()
        return bool(supplied) and hmac.compare_digest(supplied, self.server.admin_token)

    def _json_body(self):
        raw_length = self.headers.get("Content-Length", "0")
        try:
            n = int(raw_length)
        except ValueError:
            raise ValueError("invalid Content-Length")
        if n < 0 or n > MAX_BODY:
            raise ValueError(f"request body must be at most {MAX_BODY} bytes")
        if self.headers.get("Transfer-Encoding"):
            raise ValueError("chunked request bodies are not supported")
        raw = self.rfile.read(n) if n else b"{}"
        try:
            value = json.loads(raw.decode("utf-8"))
        except (UnicodeDecodeError, json.JSONDecodeError) as exc:
            raise ValueError("request must contain valid UTF-8 JSON") from exc
        if not isinstance(value, dict):
            raise ValueError("request JSON must be an object")
        return value

    def do_GET(self):
        path = urlparse(self.path).path
        if path == "/api/health":
            return self._send(200, {"ok": True, "service": "artificial-life-local"})
        if path == "/":
            try:
                body = (WEB_ROOT / "index.html").read_bytes()
            except OSError:
                return self._send(500, {"error": "web interface files are missing"})
            return self._send(200, body, "text/html; charset=utf-8")
        if path in ("/app.js", "/style.css"):
            filename = "app.js" if path == "/app.js" else "style.css"
            try:
                body = (WEB_ROOT / filename).read_bytes()
            except OSError:
                return self._send(404, {"error": "not found"})
            return self._send(200, body, "application/javascript; charset=utf-8" if filename.endswith(".js") else "text/css; charset=utf-8")
        if not self._authenticated():
            return self._send(401, {"error": "bearer token required"})
        try:
            if path == "/api/status":
                payload = self.app.store.status()
                model = os.environ.get("ALIFE_OLLAMA_MODEL", "").strip()
                payload["capabilities"] = {"local_llm": bool(model), "local_llm_model": model if model else None}
                payload["resource_limits"] = {"max_input_chars": 20000, "max_sentences_per_ingest": 80, "daily_char_budget": 100000, "daily_work_budget": 10000, "max_query_chars": 1000}
                return self._send(200, payload)
            if path == "/api/neurons":
                return self._send(200, {"neurons": self.app.store.neurons_rows()})
            if path == "/api/edges":
                return self._send(200, {"edges": self.app.store.edge_rows()})
            if path == "/api/knowledge":
                return self._send(200, {"knowledge": self.app.store.knowledge_rows()})
            if path == "/api/activity":
                rows = self.app.store.log_rows()
                for row in rows:
                    try:
                        row["detail"] = json.loads(row["detail"])
                    except Exception:
                        row["detail"] = {}
                return self._send(200, {"activity": rows})
            return self._send(404, {"error": "not found"})
        except Exception as exc:
            return self._send(500, {"error": str(exc)[:250]})

    def do_POST(self):
        # Only same-origin browser requests are accepted. A bearer header is also required.
        origin = self.headers.get("Origin")
        host = self.headers.get("Host", "")
        if origin:
            from urllib.parse import urlparse as parse_url
            if parse_url(origin).netloc != host:
                return self._send(403, {"error": "cross-origin request refused"})
        if not self._authenticated():
            return self._send(401, {"error": "bearer token required"})
        try:
            body = self._json_body()
            path = urlparse(self.path).path
            if path == "/api/learn":
                result = self.app.brain.learn(body.get("text", ""), body.get("source", "owner"))
                return self._send(200, {"ok": True, "result": result})
            if path == "/api/ask":
                result = self.app.brain.ask(body.get("question", ""), bool(body.get("use_local_llm", False)))
                return self._send(200, {"ok": True, "result": result})
            if path == "/api/feedback":
                changed = self.app.brain.feedback(body.get("knowledge_ids", []), bool(body.get("helpful", True)))
                return self._send(200, {"ok": True, "changed": changed})
            if path == "/api/pause":
                self.app.store.set_meta("paused", True)
                self.app.store.log("pause", {})
                self.app.store.db.commit()
                return self._send(200, {"ok": True, "paused": True})
            if path == "/api/resume":
                self.app.store.set_meta("paused", False)
                self.app.store.log("resume", {})
                self.app.store.db.commit()
                return self._send(200, {"ok": True, "paused": False})
            if path == "/api/rename":
                name = str(body.get("name", "")).strip()
                if not name or len(name) > 80 or any(ord(c) < 32 for c in name):
                    raise ValueError("name must be 1–80 printable characters")
                ident = self.app.store.get_meta("identity")
                ident["name"] = name
                self.app.store.set_meta("identity", ident)
                self.app.store.log("rename", {"name": name})
                self.app.store.db.commit()
                return self._send(200, {"ok": True, "identity": ident})
            return self._send(404, {"error": "not found"})
        except (ValueError, ResourceBudgetExceeded) as exc:
            return self._send(400, {"error": str(exc)[:300]})
        except Exception as exc:
            return self._send(500, {"error": str(exc)[:300]})


class Application:
    def __init__(self, home: Path):
        self.store = OrganismStore(str(home))
        self.brain = Brain(self.store, ResourceLimits())

    def close(self):
        self.store.close()


def main():
    home = Path(os.environ.get("ALIFE_HOME", str(PROJECT_ROOT / "data"))).resolve()
    home.mkdir(parents=True, exist_ok=True)
    token, created = load_or_create_token(home)
    app = Application(home)
    server = AlifeHTTPServer(("127.0.0.1", int(os.environ.get("ALIFE_PORT", "8765"))), Handler)
    server.admin_token = token
    server.app = app
    print("\nArtificial Life local organism started")
    print(f"Dashboard: http://127.0.0.1:{server.server_port}")
    print(f"Data directory: {home}")
    print(f"Admin token file: {home / 'admin_token.txt'}")
    if created:
        print("FIRST-RUN ADMIN TOKEN (copy into dashboard now):")
        print(token)
    else:
        print("Admin token already exists; read it from the token file if needed.")
    print("Bind address is 127.0.0.1 only. Press Ctrl+C to stop; knowledge survives restarts.\n")
    try:
        server.serve_forever(poll_interval=0.25)
    except KeyboardInterrupt:
        print("\nStopping organism runtime; persistent state is saved in SQLite.")
    finally:
        server.shutdown()
        server.server_close()
        app.close()


if __name__ == "__main__":
    main()
