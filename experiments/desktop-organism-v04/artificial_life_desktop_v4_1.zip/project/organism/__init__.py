"""Local artificial-life research prototype."""
