# v0.4.0 validation record

## Completed in the build environment

- `python -m py_compile run.py desktop_pet.py organism/*.py tests/*.py scripts/*.py` — passed.
- `python -m unittest discover -s tests -v` — 28 tests passed.
- `timeout 50s xvfb-run -a python scripts/windows_desktop_smoke.py` — passed under Linux/Xvfb. The smoke created the Tk floating pet and Brain Console, then created a child runtime in a separate process and verified start, pause, resume, and stop.

## Native Windows status

**Pending; not claimed as passed.** This build environment is Linux and has no native Windows desktop/runner attached. `scripts/validate_windows.ps1` runs compilation, unit/process tests, and the GUI/runtime smoke test on a real Windows machine. `.github/workflows/windows-desktop-validation.yml` provides a GitHub Actions matrix on `windows-latest` for Python 3.10, 3.11, and 3.12. A native Windows result should only be recorded after that command/workflow completes successfully.

## Limits of the smoke test

The GUI test confirms window creation and child lifecycle calls; it does not prove every transparency configuration, multi-monitor behavior, startup-task behavior, long-term stability, OS-level resource limits, or consciousness.
