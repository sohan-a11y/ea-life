"""Exercise the actual Tk desktop UI and a child organism on the current OS.

On Windows this is the native-Windows smoke test used by GitHub Actions. It creates a
floating pet and the full console, then verifies a child can start, pause, resume, stop,
and persist its independent process health. It does not need a model download.
"""
from __future__ import annotations

import json
import os
import sys
import tempfile
import time
from pathlib import Path


def main() -> int:
    temporary = tempfile.TemporaryDirectory(prefix="alife-windows-smoke-")
    home = Path(temporary.name) / "data"
    os.environ["ALIFE_HOME"] = str(home)
    sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

    # Importing only after setting ALIFE_HOME keeps the smoke test isolated.
    from desktop_pet import DesktopPet
    from organism.brain import Brain
    from organism.store import OrganismStore

    store = OrganismStore(str(home))
    app = DesktopPet(store, Brain(store, semantic_autoindex=False))
    result = {"ok": False, "steps": [], "platform": sys.platform}
    state = {"phase": "starting", "deadline": time.monotonic() + 40.0, "child": None}

    try:
        app.show_panel()
        app.root.update_idletasks()
        if not app.root.winfo_exists() or app.panel is None or not app.panel.winfo_exists():
            raise RuntimeError("floating pet or brain console did not create a native window")
        result["steps"].append("native Tk floating pet and console created")

        child = app.colony.create("Windows Smoke Child")
        state["child"] = child["id"]
        app.refresh_all()
        app.runtime_supervisor.start_organism(child["id"])
        state["phase"] = "wait_running"

        def finish(ok: bool, message: str = "") -> None:
            result["ok"] = ok
            if message:
                result["error"] = message
            result["final_runtime_snapshot"] = next(
                (row for row in app.runtime_supervisor.poll() if row["id"] == child["id"]), {}
            )
            print("WINDOWS_DESKTOP_SMOKE_REPORT=" + json.dumps(result, ensure_ascii=False))
            app.close()

        def poll_step() -> None:
            if time.monotonic() > state["deadline"]:
                finish(False, f"timed out during phase {state['phase']}")
                return
            try:
                row = next((item for item in app.runtime_supervisor.poll() if item["id"] == child["id"]), None)
                if row is None:
                    raise RuntimeError("child disappeared from supervisor registry")
                phase = state["phase"]
                if phase == "wait_running" and row.get("alive") and row.get("runtime_state") == "running":
                    if row.get("pid") == os.getpid():
                        raise RuntimeError("child runtime did not start as a separate process")
                    result["steps"].append("child started in a separate process")
                    app.runtime_supervisor.pause_organism(child["id"])
                    state["phase"] = "wait_paused"
                elif phase == "wait_paused" and row.get("runtime_state") == "paused":
                    result["steps"].append("child pause acknowledged")
                    app.runtime_supervisor.resume_organism(child["id"])
                    state["phase"] = "wait_resumed"
                elif phase == "wait_resumed" and row.get("alive") and row.get("runtime_state") == "running":
                    result["steps"].append("child resumed")
                    app.runtime_supervisor.stop_organism(child["id"], timeout=5.0)
                    state["phase"] = "wait_stopped"
                elif phase == "wait_stopped" and row.get("runtime_state") == "stopped" and not row.get("alive"):
                    result["steps"].append("child stopped cleanly")
                    finish(True)
                    return
            except Exception as exc:
                finish(False, f"{type(exc).__name__}: {exc}")
                return
            app.root.after(250, poll_step)

        app.root.after(250, poll_step)
        app.run()
        return 0 if result["ok"] else 1
    finally:
        try:
            app.runtime_supervisor.close(timeout=1.0)
        except Exception:
            pass
        try:
            temporary.cleanup()
        except Exception:
            pass


if __name__ == "__main__":
    raise SystemExit(main())
