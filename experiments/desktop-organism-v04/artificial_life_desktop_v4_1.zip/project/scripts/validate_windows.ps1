$ErrorActionPreference = 'Stop'
$ProjectRoot = Split-Path -Parent (Split-Path -Parent $MyInvocation.MyCommand.Path)
Set-Location $ProjectRoot

Write-Host '== Python version =='
python --version
if ($LASTEXITCODE -ne 0) { throw 'Python is unavailable. Install Python 3.10 or newer and enable PATH.' }

Write-Host '== Dependencies =='
python -m pip install --upgrade pip
if ($LASTEXITCODE -ne 0) { throw 'pip upgrade failed.' }
python -m pip install -r requirements.txt
if ($LASTEXITCODE -ne 0) { throw 'Dependency installation failed.' }

Write-Host '== Compile source =='
python -c "import pathlib, py_compile; root=pathlib.Path('.'); files=[root/'run.py', root/'desktop_pet.py', *sorted((root/'organism').glob('*.py')), *sorted((root/'tests').glob('*.py')), *sorted((root/'scripts').glob('*.py'))]; [py_compile.compile(str(path), doraise=True) for path in files]; print(f'Compiled {len(files)} Python files')"
if ($LASTEXITCODE -ne 0) { throw 'Python compilation failed.' }

Write-Host '== Unit and process lifecycle tests =='
python -m unittest discover -s tests -v
if ($LASTEXITCODE -ne 0) { throw 'Unit tests failed.' }

Write-Host '== Native Windows Tk desktop + child-runtime smoke =='
$env:ALIFE_HOME = Join-Path $env:TEMP ('alife-windows-validation-' + [guid]::NewGuid().ToString('N'))
python scripts/windows_desktop_smoke.py
if ($LASTEXITCODE -ne 0) { throw 'Native desktop smoke test failed. See output above and runtime_worker_process.log in the reported test data folder if it remains.' }

Write-Host 'WINDOWS_VALIDATION=PASS'
