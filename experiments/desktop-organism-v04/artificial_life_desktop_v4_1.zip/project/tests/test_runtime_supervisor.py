import json
import os
import tempfile
import time
import unittest
from pathlib import Path

from organism.colony import Colony
from organism.runtime_supervisor import ColonyRuntimeSupervisor


class RuntimeSupervisorTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.home = Path(self.temp.name)
        self.colony = Colony(self.home / "colony")
        self.child = self.colony.create("Child runtime")
        self.supervisor = ColonyRuntimeSupervisor(self.colony, project_root=Path(__file__).resolve().parents[1])
        self.supervisor.start()

    def tearDown(self):
        try:
            self.supervisor.stop_all()
            self.supervisor.close(timeout=2.0)
        except Exception:
            pass
        self.temp.cleanup()

    def wait_for(self, predicate, timeout=12.0, message="condition not reached"):
        deadline = time.time() + timeout
        latest = None
        while time.time() < deadline:
            latest = self.supervisor.poll()
            target = next((row for row in latest if row["id"] == self.child["id"]), None)
            if target is not None and predicate(target):
                return target
            time.sleep(0.25)
        snapshot = target if 'target' in locals() else latest
        if isinstance(snapshot, dict):
            worker_home = snapshot.get("home")
            if worker_home:
                for name in ("runtime_status.json", "runtime_worker_process.log"):
                    path = Path(worker_home) / name
                    try:
                        content = path.read_text(encoding="utf-8")
                        print(f"RUNTIME_DIAGNOSTIC_{name.upper()}=" + content[-12000:])
                    except OSError:
                        pass
        self.fail(f"{message}; last snapshot={snapshot}")


    def test_child_has_own_process_and_pause_resume_stop_lifecycle(self):
        started = self.supervisor.start_organism(self.child["id"])
        self.assertIsNotNone(started["pid"])
        running = self.wait_for(lambda row: row.get("alive") and row.get("runtime_state") == "running", message="child failed to start")
        self.assertNotEqual(running["pid"], os.getpid())
        self.assertEqual(running["desired_state"], "running")

        self.supervisor.pause_organism(self.child["id"])
        paused = self.wait_for(lambda row: row.get("runtime_state") == "paused", message="child failed to pause")
        self.assertEqual(paused["desired_state"], "paused")

        self.supervisor.resume_organism(self.child["id"])
        resumed = self.wait_for(lambda row: row.get("alive") and row.get("runtime_state") == "running", message="child failed to resume")
        self.assertEqual(resumed["desired_state"], "running")

        self.supervisor.stop_organism(self.child["id"], timeout=5.0)
        stopped = self.supervisor.poll()
        target = next(row for row in stopped if row["id"] == self.child["id"])
        self.assertEqual(target["runtime_state"], "stopped")
        self.assertFalse(target["alive"])
        desired = json.loads((self.colony.home / "runtime_desired.json").read_text(encoding="utf-8"))
        self.assertEqual(desired[self.child["id"]], "stopped")

    def test_supervisor_restarts_unexpected_worker_exit(self):
        self.supervisor.start_organism(self.child["id"])
        first = self.wait_for(lambda row: row.get("alive") and row.get("runtime_state") == "running", message="worker failed to start")
        proc = self.supervisor._processes[self.child["id"]]
        proc.terminate()
        proc.wait(timeout=5)
        deadline = time.time() + 8
        replacement = None
        while time.time() < deadline:
            self.supervisor.poll()
            candidate = self.supervisor._processes.get(self.child["id"])
            if candidate is not None and candidate.poll() is None and candidate.pid != first["pid"]:
                replacement = candidate
                break
            time.sleep(0.25)
        self.assertIsNotNone(replacement, "worker did not restart after unexpected exit")
        self.assertNotEqual(replacement.pid, first["pid"])
        running_again = self.wait_for(lambda row: row.get("alive") and row.get("runtime_state") == "running", message="replacement worker never became healthy")
        self.assertEqual(running_again["pid"], replacement.pid)


if __name__ == "__main__":
    unittest.main()
