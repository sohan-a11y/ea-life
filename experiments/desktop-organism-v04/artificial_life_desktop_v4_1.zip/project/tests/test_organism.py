import json
import os
import sqlite3
import tempfile
import threading
import unittest
from pathlib import Path
from urllib.request import Request, urlopen
from urllib.error import HTTPError

from organism.brain import Brain
from organism.life import LifeController
from organism.resources import ResourceBudgetExceeded, ResourceLimits
from organism.server import AlifeHTTPServer, Application, Handler, load_or_create_token
from organism.store import OrganismStore
from organism.prediction import PredictionEngine
from organism.goals import GoalManager
from organism.permissions import PermissionedFiles
from organism.colony import Colony
from organism.dynamics import AdaptiveSubstrate
from organism.semantic import LocalSemanticMemory
from organism.runtime_guard import RuntimeGuard


class StoreBrainTests(unittest.TestCase):
    def setUp(self):
        self._old_embed_model = os.environ.pop("ALIFE_OLLAMA_EMBED_MODEL", None)
        self.tmp = tempfile.TemporaryDirectory()
        self.store = OrganismStore(self.tmp.name)
        self.brain = Brain(self.store, ResourceLimits(daily_char_budget=40000))

    def tearDown(self):
        self.store.close()
        self.tmp.cleanup()
        if self._old_embed_model is not None:
            os.environ["ALIFE_OLLAMA_EMBED_MODEL"] = self._old_embed_model

    def test_identity_persists(self):
        identity = self.store.get_meta("identity")
        self.assertTrue(identity["id"])
        path = self.store.db_path
        self.store.close()
        self.store = OrganismStore(str(path.parent))
        self.assertEqual(self.store.get_meta("identity")["id"], identity["id"])

    def test_ingest_grows_memory_concepts_and_edges(self):
        result = self.brain.learn("Neurons store concepts. Concepts connect through shared knowledge.", "test-doc")
        self.assertGreaterEqual(result["new_memory_neurons"], 2)
        self.assertGreater(result["new_concept_neurons"], 0)
        self.assertGreater(result["edge_updates"], 0)
        status = self.store.status()
        self.assertEqual(status["knowledge_items"], 2)
        self.assertGreater(status["relationships"], 0)

    def test_duplicate_reinforces_instead_of_duplicate_memory(self):
        a = self.brain.learn("Memory grows when knowledge repeats.", "a")
        b = self.brain.learn("Memory grows when knowledge repeats.", "b")
        self.assertEqual(a["new_knowledge"], 1)
        self.assertEqual(b["new_knowledge"], 0)
        self.assertEqual(b["duplicate_statements"], 1)
        self.assertEqual(self.store.status()["knowledge_items"], 1)
        rows = self.store.knowledge_rows()
        self.assertEqual(rows[0]["seen_count"], 2)

    def test_retrieval_has_evidence_and_feedback(self):
        self.brain.learn("Neuron growth creates a new concept when unfamiliar information arrives.", "notes")
        self.brain.learn("A resource budget limits daily information intake.", "manual")
        answer = self.brain.ask("How does neuron growth work?")
        self.assertTrue(answer["evidence"])
        self.assertIn("neuron", answer["evidence"][0]["text"].lower())
        n = self.brain.feedback([e["id"] for e in answer["evidence"]], True)
        self.assertGreater(n, 0)

    def test_budgets_and_pause_enforced(self):
        brain = Brain(self.store, ResourceLimits(max_input_chars=10, daily_char_budget=40))
        with self.assertRaises(ResourceBudgetExceeded):
            brain.learn("This text is too long")
        self.store.set_meta("paused", True)
        with self.assertRaises(ValueError):
            self.brain.learn("A valid memory.")
        with self.assertRaises(ValueError):
            self.brain.ask("Find a memory")

    def test_daily_limit_enforced(self):
        brain = Brain(self.store, ResourceLimits(max_input_chars=100, daily_char_budget=20))
        brain.learn("Neuron grows.")
        with self.assertRaises(ResourceBudgetExceeded):
            brain.learn("Another knowledge sentence.")

    def test_work_budget_and_statement_limit_enforced(self):
        limited = Brain(self.store, ResourceLimits(max_input_chars=1000, daily_char_budget=1000, daily_work_budget=1, max_sentences_per_ingest=2))
        with self.assertRaises(ResourceBudgetExceeded):
            limited.learn("Neuron grows.")
        statement_limited = Brain(self.store, ResourceLimits(max_input_chars=1000, daily_char_budget=1000, max_sentences_per_ingest=2))
        with self.assertRaises(ResourceBudgetExceeded):
            statement_limited.learn("One. Two. Three.")

    def test_potential_conflicts_are_flagged_without_overwriting_source_memories(self):
        self.brain.learn("The server is available for traffic.", "monitor-A")
        self.brain.learn("The server is not available for traffic.", "monitor-B")
        rows = self.store.knowledge_rows(limit=10)
        self.assertEqual(len(rows), 2)
        self.assertEqual({r["source"] for r in rows}, {"monitor-A", "monitor-B"})
        n = self.store.db.execute("SELECT COUNT(*) FROM edges WHERE relation='potential_conflict'").fetchone()[0]
        self.assertGreaterEqual(n, 1)

    def test_bounded_reflection_adds_associations(self):
        self.brain.learn("Neural systems create adaptive memory connections.", "a")
        self.brain.learn("Neural systems strengthen memory connections through repetition.", "b")
        result = self.brain.reflect(max_memories=20, max_new_associations=5)
        self.assertGreaterEqual(result["memories_examined"], 2)
        self.assertGreaterEqual(result["new_associations"], 1)
        self.assertGreaterEqual(self.store.db.execute("SELECT COUNT(*) FROM edges WHERE relation='associates'").fetchone()[0], 1)

    def test_spreading_activation_can_retrieve_a_linked_memory(self):
        self.brain.learn("Networks form neural pathways in this model.", "memory-one")
        self.brain.learn("Neural pathways connect adaptive memory systems.", "memory-two")
        result = self.brain.ask("networks")
        evidence_text = [row["text"] for row in result["evidence"]]
        self.assertTrue(any("adaptive memory systems" in text for text in evidence_text), evidence_text)
        self.assertGreater(self.store.db.execute("SELECT MAX(activation) FROM neurons").fetchone()[0], 0.0)

    def test_missing_answer_becomes_goal_and_resolves_when_evidence_exists(self):
        question = "How does quantum moss preserve its silver memory?"
        result = self.brain.ask(question)
        self.assertFalse(result["evidence"])
        goals = self.store.get_meta("pending_goals", [])
        self.assertEqual(len(goals), 1)
        self.brain.learn("Quantum moss preserves its silver memory by storing crystal patterns.", "lab-note")
        result = self.brain.ask(question)
        self.assertTrue(result["evidence"])
        self.assertEqual(self.store.get_meta("pending_goals", []), [])

    def test_life_controller_persists_state_and_respects_pause(self):
        life = LifeController(self.store, self.brain)
        self.brain.learn("A bounded system can make controlled memory associations.", "test")
        state = life.tick(force_reflection=True)
        self.assertFalse(state["paused"])
        self.assertGreaterEqual(state["cycle_count"], 1)
        self.assertGreaterEqual(state["reflection_count"], 1)
        saved_id = self.store.get_meta("identity")["id"]
        self.assertEqual(self.brain.self_model()["identity"]["id"], saved_id)
        self.store.set_meta("paused", True)
        paused_state = life.tick(force_reflection=True)
        self.assertTrue(paused_state["paused"])


    def test_prediction_engine_records_observed_outcome(self):
        engine = PredictionEngine(self.store)
        p = engine.predict("after learning", "memory count increases", 0.8)
        result = engine.observe(p["id"], "memory count increases")
        self.assertEqual(result["status"], "evaluated")
        self.assertEqual(result["prediction_error_proxy"], 0.0)
        with self.assertRaises(ValueError): engine.observe(p["id"], "again")

    def test_goal_lifecycle(self):
        manager = GoalManager(self.store)
        goal = manager.create("Learn about neural networks", "Explain backpropagation", priority=5)
        self.assertEqual(manager.next()["id"], goal["id"])
        manager.update(goal["id"], status="in_progress", note="Started reading")
        self.assertEqual(manager.list()[0]["notes"][0]["text"], "Started reading")
        manager.update(goal["id"], status="completed")
        self.assertIsNone(manager.next())

    def test_permissioned_file_ingestion_requires_grant(self):
        with tempfile.TemporaryDirectory() as home:
            path=Path(home)/"notes.txt"; path.write_text("Adaptive systems learn from observed outcomes.",encoding="utf-8")
            files=PermissionedFiles(self.brain,self.store)
            with self.assertRaises(PermissionError): files.ingest(path)
            files.grant(path); result=files.ingest(path)
            self.assertEqual(result["new_knowledge"],1)
            files.revoke(path)
            with self.assertRaises(PermissionError): files.ingest(path)

    def test_colony_isolates_organisms_and_supports_encrypted_broadcast(self):
        with tempfile.TemporaryDirectory() as home:
            colony=Colony(home); one=colony.create("One"); two=colony.create("Two",parent_id=one["id"])
            self.assertEqual(two["generation"],2)
            messages=colony.broadcast("Hello colony")
            self.assertEqual(len(messages),2)
            store=OrganismStore(one["home"])
            try:
                raw = store.get_meta("inbox")[0]
                self.assertNotIn("message", raw)
                self.assertNotIn("Hello colony", json.dumps(raw))
            finally: store.close()
            decoded = colony.read_inbox(one["id"])
            self.assertEqual(decoded[0]["message"], "Hello colony")
            self.assertTrue(decoded[0]["encrypted"])
            self.assertTrue(colony.security_status()["enabled"])

    def test_colony_detects_tampered_encrypted_message(self):
        with tempfile.TemporaryDirectory() as home:
            colony = Colony(home); one = colony.create("One")
            colony.deliver(one["id"], "do not tamper")
            store = OrganismStore(one["home"])
            try:
                inbox = store.get_meta("inbox")
                token = inbox[0]["token"]
                inbox[0]["token"] = ("A" if token[0] != "A" else "B") + token[1:]
                store.set_meta("inbox", inbox); store.db.commit()
            finally: store.close()
            decoded = colony.read_inbox(one["id"])
            self.assertTrue(decoded[0]["invalid"])
            self.assertIn("failed authentication", decoded[0]["message"])

    def test_adaptive_recurrent_substrate_persists_online_plasticity(self):
        substrate = AdaptiveSubstrate(self.store)
        before = self.store.get_meta("adaptive_input_weights")
        result = substrate.process("Neural learning changes recurrent weights from experience.", learn=True)
        after = self.store.get_meta("adaptive_input_weights")
        self.assertTrue(result["learned"])
        self.assertEqual(substrate.report()["plasticity_updates"], 1)
        self.assertNotEqual(before, after)
        self.assertGreaterEqual(substrate.report()["units"], 16)
        self.assertGreaterEqual(substrate.resonance("neural learning", "recurrent weights"), -1.0)
        self.assertLessEqual(substrate.resonance("neural learning", "recurrent weights"), 1.0)

    def test_semantic_memory_is_optional_and_cosine_is_bounded(self):
        semantic = LocalSemanticMemory(self.store, model="")
        self.assertFalse(semantic.enabled)
        self.assertEqual(semantic.rank("anything", []), [])
        self.assertAlmostEqual(semantic.cosine([1.0, 0.0], [1.0, 0.0]), 1.0)
        self.assertAlmostEqual(semantic.cosine([1.0, 0.0], [0.0, 1.0]), 0.0)

    def test_semantic_index_cache_and_rank_with_stubbed_local_embedding_backend(self):
        semantic = LocalSemanticMemory(self.store, model="test-local-embedding")
        def fake_embed(texts):
            vectors = []
            for text in texts:
                lowered = text.lower()
                vectors.append([1.0, 0.0] if "apple" in lowered or "orchard" in lowered else [0.0, 1.0])
            return vectors
        semantic._embed = fake_embed
        rows = [
            {"text": "Apple fruit grows in an orchard."},
            {"text": "A car engine uses fuel."},
        ]
        result = semantic.index_rows(rows, limit=2)
        self.assertEqual(result["new_embeddings"], 2)
        ranked = semantic.rank("apple orchard", rows, limit=2)
        self.assertGreater(ranked[0]["similarity"], ranked[1]["similarity"])

    def test_brain_uses_cached_semantic_vectors_when_words_do_not_overlap(self):
        self.brain.semantic.model = "stub-semantic-model"
        def fake_embed(texts):
            result = []
            for text in texts:
                lowered = text.lower()
                result.append([1.0, 0.0] if any(word in lowered for word in ("river", "azure", "illumination")) else [0.0, 1.0])
            return result
        self.brain.semantic._embed = fake_embed
        self.brain.learn("The river glows with blue light.", "field-notes")
        answer = self.brain.ask("Describe the azure illumination.")
        self.assertTrue(answer["evidence"])
        self.assertIn("river glows", answer["evidence"][0]["text"].lower())
        self.assertEqual(answer["semantic_model"], "stub-semantic-model")

    def test_database_snapshot_is_valid(self):
        guard = RuntimeGuard(self.store, self.tmp.name)
        self.brain.learn("Snapshot tests verify recoverable persistent storage.", "test")
        snapshot = guard.snapshot_database(keep=3)
        self.assertTrue(Path(snapshot["path"]).exists())
        con = sqlite3.connect(snapshot["path"])
        try: self.assertEqual(con.execute("PRAGMA quick_check").fetchone()[0], "ok")
        finally: con.close()


class MigrationTests(unittest.TestCase):
    def test_existing_database_receives_activation_column(self):
        with tempfile.TemporaryDirectory() as home:
            db_path = Path(home) / "organism.sqlite3"
            con = sqlite3.connect(db_path)
            con.executescript("""
                CREATE TABLE meta (key TEXT PRIMARY KEY, value TEXT NOT NULL);
                CREATE TABLE neurons (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    neuron_key TEXT NOT NULL UNIQUE,
                    kind TEXT NOT NULL CHECK(kind IN ('memory','concept')),
                    label TEXT NOT NULL, terms TEXT NOT NULL,
                    strength REAL NOT NULL DEFAULT 1.0,
                    activation_count INTEGER NOT NULL DEFAULT 0,
                    created_at REAL NOT NULL, last_activated REAL
                );
            """)
            con.close()
            store = OrganismStore(home)
            try:
                columns = {r[1] for r in store.db.execute("PRAGMA table_info(neurons)")}
                self.assertIn("activation", columns)
                self.assertEqual(store.neurons_rows(), [])
            finally:
                store.close()


class APITests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.app = Application(Path(self.tmp.name) / "data")
        self.token = "test-token-for-api-authentication-123456789"
        self.server = AlifeHTTPServer(("127.0.0.1", 0), Handler)
        self.server.app = self.app
        self.server.admin_token = self.token
        self.thread = threading.Thread(target=self.server.serve_forever, daemon=True)
        self.thread.start()
        self.base = f"http://127.0.0.1:{self.server.server_port}"

    def tearDown(self):
        self.server.shutdown(); self.server.server_close(); self.thread.join(timeout=2)
        self.app.close(); self.tmp.cleanup()

    def request(self, path, body=None, token=None):
        data = json.dumps(body).encode() if body is not None else None
        headers = {}
        if token: headers["Authorization"] = "Bearer " + token
        if body is not None: headers["Content-Type"] = "application/json"
        req = Request(self.base + path, data=data, headers=headers)
        try:
            with urlopen(req, timeout=3) as res: return res.status, json.loads(res.read())
        except HTTPError as e: return e.code, json.loads(e.read())

    def test_auth_required_and_learning_api(self):
        code, _ = self.request("/api/status")
        self.assertEqual(code, 401)
        code, payload = self.request("/api/learn", {"text":"A neuron learns a concept."}, self.token)
        self.assertEqual(code, 200)
        self.assertEqual(payload["result"]["new_knowledge"], 1)
        code, status = self.request("/api/status", token=self.token)
        self.assertEqual(code, 200)
        self.assertEqual(status["knowledge_items"], 1)

    def test_health_is_public_and_pause_endpoint_protected(self):
        code, body = self.request("/api/health")
        self.assertEqual((code, body["ok"]), (200, True))
        code, _ = self.request("/api/pause", {})
        self.assertEqual(code, 401)
        code, _ = self.request("/api/pause", {}, self.token)
        self.assertEqual(code, 200)
        self.assertTrue(self.app.store.get_meta("paused"))

    def test_token_created_once(self):
        p = Path(self.tmp.name) / "tokenhome"
        one, created = load_or_create_token(p)
        two, created_again = load_or_create_token(p)
        self.assertTrue(created)
        self.assertFalse(created_again)
        self.assertEqual(one, two)


if __name__ == "__main__":
    unittest.main()
