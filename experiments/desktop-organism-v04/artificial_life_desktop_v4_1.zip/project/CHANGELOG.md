# Changelog\n\n## v0.4.1 — Windows child-runtime compatibility\n- Use the supervisor heartbeat as the authoritative cross-platform parent-liveness check.\n- Emit worker boot/exit diagnostics and preserve final worker state across crash-loop protection.\n\n# Changelog

## 0.3.0 — Integrated cognitive and agency workbench

- Added persistent 24-unit recurrent substrate with bounded local Oja-style plasticity and experimental recurrent-resonance ranking.
- Added optional Ollama-local semantic embeddings, SQLite vector cache, manual batched indexing, and semantic retrieval reranking.
- Integrated goals, prediction/outcome tracking, permissioned file access, colony creation, parent/child metadata, knowledge inheritance, inbox delivery and creator broadcast into the desktop console.
- Added Fernet-authenticated encrypted local colony inbox envelopes with tamper detection, atomic colony-index replacement, and explicit local-key security limits.
- Added best-effort process RSS/CPU monitoring, background cognition backoff, rotating diagnostics, and validated SQLite snapshots retained in a three-snapshot ring.
- Added regression tests for recurrent plasticity, semantic indexing/retrieval, encrypted-message tampering, snapshot integrity and core workflows.
- Updated architecture, setup instructions and capability-gap register to distinguish implemented functionality from consciousness claims and future work.


## 0.4.0 — supervised colony runtimes

- Added one supervised Python process per non-primary colony organism.
- Added persisted desired state, owner heartbeat, worker health files, crash restart/backoff and a crash-loop lockout with explicit manual recovery.
- Added child lifecycle controls and runtime state display to the Colony UI.
- Workers monitor pending inbox counts but never execute inbox text as instructions or code.
- Added process-level lifecycle and restart tests plus a native Tk/child-runtime smoke script and Windows PowerShell validator.
- Added GitHub Actions CI for Windows Python 3.10–3.12. The CI workflow is ready to run; it is not evidence of a completed Windows result until a runner reports success.
