param([switch]$Uninstall)
$ErrorActionPreference = 'Stop'
$TaskName = 'Artificial Life Pet'

if ($Uninstall) {
    $task = Get-ScheduledTask -TaskName $TaskName -ErrorAction SilentlyContinue
    if ($task) { Unregister-ScheduledTask -TaskName $TaskName -Confirm:$false }
    Write-Host 'Artificial Life Pet startup task removed.'
    exit 0
}

$ProjectRoot = (Resolve-Path $PSScriptRoot).Path
$PythonLine = (& py -3 -c "import sys; print(sys.executable)" 2>$null | Select-Object -Last 1)
if (-not $PythonLine) { throw 'Python 3 was not found through the py launcher. Install Python 3.10+ and ensure the py launcher is available.' }
$PythonExe = $PythonLine.Trim()
$Pythonw = Join-Path (Split-Path $PythonExe -Parent) 'pythonw.exe'
if (Test-Path $Pythonw) { $PythonExe = $Pythonw }
$Script = Join-Path $ProjectRoot 'run.py'
$Action = New-ScheduledTaskAction -Execute $PythonExe -Argument ('"' + $Script + '"') -WorkingDirectory $ProjectRoot
$Trigger = New-ScheduledTaskTrigger -AtLogOn -User $env:USERNAME
$Principal = New-ScheduledTaskPrincipal -UserId $env:USERNAME -LogonType Interactive -RunLevel Limited
$Settings = New-ScheduledTaskSettingsSet -StartWhenAvailable -AllowStartIfOnBatteries -DontStopIfGoingOnBatteries -ExecutionTimeLimit ([TimeSpan]::Zero)
Register-ScheduledTask -TaskName $TaskName -Action $Action -Trigger $Trigger -Principal $Principal -Settings $Settings -Description 'Start the local Artificial Life desktop pet at sign-in.' -Force | Out-Null
Write-Host 'Startup task installed for the current Windows user.'
Write-Host 'To remove it later: powershell -ExecutionPolicy Bypass -File .\install_startup_windows.ps1 -Uninstall'
